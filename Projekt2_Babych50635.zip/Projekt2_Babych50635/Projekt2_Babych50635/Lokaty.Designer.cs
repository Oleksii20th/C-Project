﻿namespace Projekt2_Babych50635
{
    partial class obLokaty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.oblabel1 = new System.Windows.Forms.Label();
            this.oblblK = new System.Windows.Forms.Label();
            this.oblbln = new System.Windows.Forms.Label();
            this.oblblp = new System.Windows.Forms.Label();
            this.oblblWykres = new System.Windows.Forms.Label();
            this.oblblRozliczenieTabeleryczne = new System.Windows.Forms.Label();
            this.oblblKnm = new System.Windows.Forms.Label();
            this.obtxtK = new System.Windows.Forms.TextBox();
            this.obtxtn = new System.Windows.Forms.TextBox();
            this.obtxtKnm = new System.Windows.Forms.TextBox();
            this.obcmbRocznaStopaProcentowa = new System.Windows.Forms.ComboBox();
            this.obgpCzętośćKapitalizacjiOdsetek = new System.Windows.Forms.GroupBox();
            this.obrdbCoMiesiąc = new System.Windows.Forms.RadioButton();
            this.obrdbCoKwartal = new System.Windows.Forms.RadioButton();
            this.obrdbCoPółRoku = new System.Windows.Forms.RadioButton();
            this.obrdbCoRoku = new System.Windows.Forms.RadioButton();
            this.obdgvTabeleryczneRozliczenieLokaty = new System.Windows.Forms.DataGridView();
            this.Numerokresulokaty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stannapoczątkuokresulokaty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Odsetkizadanyokreslokaty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stannakońcuokresulokaty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obbtnObliczKnm = new System.Windows.Forms.Button();
            this.obbtnRozliczLokateTabelaryczne = new System.Windows.Forms.Button();
            this.obbtnGraficznarozliczenialokaty = new System.Windows.Forms.Button();
            this.obbtnResetuj = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.obchtWykres = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.obbtnZmieńkolorliniiwykresu = new System.Windows.Forms.Button();
            this.obtbGrubośćlinii = new System.Windows.Forms.TrackBar();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.obwyjścieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obtypWykresuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obkolorLiniiWykresuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obkolorTłaWykresuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obstylLiniiWykresuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obkreskowaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obkreskowoKropkowaDashDotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obpowrótDoFormularzaKredytówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obbtnZmieńkolortła = new System.Windows.Forms.Button();
            this.oblblGrubośćlinii = new System.Windows.Forms.Label();
            this.obcmbGrubośćlinii = new System.Windows.Forms.ComboBox();
            this.oblistbStylliniiwykresu = new System.Windows.Forms.ListBox();
            this.oblblStyllinii = new System.Windows.Forms.Label();
            this.obbtnPowrótdokokpitu = new System.Windows.Forms.Button();
            this.obgpCzętośćKapitalizacjiOdsetek.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvTabeleryczneRozliczenieLokaty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obchtWykres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obtbGrubośćlinii)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // oblabel1
            // 
            this.oblabel1.AutoSize = true;
            this.oblabel1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblabel1.Location = new System.Drawing.Point(478, 28);
            this.oblabel1.Name = "oblabel1";
            this.oblabel1.Size = new System.Drawing.Size(503, 32);
            this.oblabel1.TabIndex = 0;
            this.oblabel1.Text = "Formularz rozliczenia lokaty kapitalowej";
            // 
            // oblblK
            // 
            this.oblblK.AutoSize = true;
            this.oblblK.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblK.Location = new System.Drawing.Point(6, 66);
            this.oblblK.Name = "oblblK";
            this.oblblK.Size = new System.Drawing.Size(269, 19);
            this.oblblK.TabIndex = 1;
            this.oblblK.Text = "Lokaty kapitalowa (początkowa) K:";
            // 
            // oblbln
            // 
            this.oblbln.AutoSize = true;
            this.oblbln.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblbln.Location = new System.Drawing.Point(6, 141);
            this.oblbln.Name = "oblbln";
            this.oblbln.Size = new System.Drawing.Size(142, 19);
            this.oblbln.TabIndex = 2;
            this.oblbln.Text = "Liczba lat lokat n:";
            // 
            // oblblp
            // 
            this.oblblp.AutoSize = true;
            this.oblblp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblp.Location = new System.Drawing.Point(7, 213);
            this.oblblp.Name = "oblblp";
            this.oblblp.Size = new System.Drawing.Size(214, 19);
            this.oblblp.TabIndex = 3;
            this.oblblp.Text = "Roczna stopa procentowa p:";
            // 
            // oblblWykres
            // 
            this.oblblWykres.AutoSize = true;
            this.oblblWykres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblWykres.Location = new System.Drawing.Point(480, 66);
            this.oblblWykres.Name = "oblblWykres";
            this.oblblWykres.Size = new System.Drawing.Size(479, 20);
            this.oblblWykres.TabIndex = 4;
            this.oblblWykres.Text = "Wykres zmiany stanu konta w okresie lokaty kapitalowej";
            this.oblblWykres.Visible = false;
            // 
            // oblblRozliczenieTabeleryczne
            // 
            this.oblblRozliczenieTabeleryczne.AutoSize = true;
            this.oblblRozliczenieTabeleryczne.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblRozliczenieTabeleryczne.Location = new System.Drawing.Point(522, 82);
            this.oblblRozliczenieTabeleryczne.Name = "oblblRozliczenieTabeleryczne";
            this.oblblRozliczenieTabeleryczne.Size = new System.Drawing.Size(345, 20);
            this.oblblRozliczenieTabeleryczne.TabIndex = 5;
            this.oblblRozliczenieTabeleryczne.Text = "Tablicowe rozliczenia lokaty kapitalowej";
            this.oblblRozliczenieTabeleryczne.Visible = false;
            // 
            // oblblKnm
            // 
            this.oblblKnm.AutoSize = true;
            this.oblblKnm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblKnm.Location = new System.Drawing.Point(1116, 122);
            this.oblblKnm.Name = "oblblKnm";
            this.oblblKnm.Size = new System.Drawing.Size(223, 20);
            this.oblblKnm.TabIndex = 6;
            this.oblblKnm.Text = "Przyszły stan konta Knm:";
            this.oblblKnm.Visible = false;
            // 
            // obtxtK
            // 
            this.obtxtK.Location = new System.Drawing.Point(9, 99);
            this.obtxtK.Name = "obtxtK";
            this.obtxtK.Size = new System.Drawing.Size(196, 22);
            this.obtxtK.TabIndex = 7;
            this.obtxtK.Text = "1000";
            this.obtxtK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // obtxtn
            // 
            this.obtxtn.Location = new System.Drawing.Point(9, 173);
            this.obtxtn.Name = "obtxtn";
            this.obtxtn.Size = new System.Drawing.Size(193, 22);
            this.obtxtn.TabIndex = 8;
            this.obtxtn.Text = "5";
            this.obtxtn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // obtxtKnm
            // 
            this.obtxtKnm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obtxtKnm.Location = new System.Drawing.Point(1120, 145);
            this.obtxtKnm.Name = "obtxtKnm";
            this.obtxtKnm.ReadOnly = true;
            this.obtxtKnm.Size = new System.Drawing.Size(193, 30);
            this.obtxtKnm.TabIndex = 9;
            this.obtxtKnm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.obtxtKnm.Visible = false;
            // 
            // obcmbRocznaStopaProcentowa
            // 
            this.obcmbRocznaStopaProcentowa.FormattingEnabled = true;
            this.obcmbRocznaStopaProcentowa.Items.AddRange(new object[] {
            "2,1%",
            "2,2%",
            "2,3%",
            "2,4%",
            "2,5%",
            "2,6%"});
            this.obcmbRocznaStopaProcentowa.Location = new System.Drawing.Point(10, 245);
            this.obcmbRocznaStopaProcentowa.Name = "obcmbRocznaStopaProcentowa";
            this.obcmbRocznaStopaProcentowa.Size = new System.Drawing.Size(231, 24);
            this.obcmbRocznaStopaProcentowa.TabIndex = 10;
            this.obcmbRocznaStopaProcentowa.Text = "2,1%";
            // 
            // obgpCzętośćKapitalizacjiOdsetek
            // 
            this.obgpCzętośćKapitalizacjiOdsetek.Controls.Add(this.obrdbCoMiesiąc);
            this.obgpCzętośćKapitalizacjiOdsetek.Controls.Add(this.obrdbCoKwartal);
            this.obgpCzętośćKapitalizacjiOdsetek.Controls.Add(this.obrdbCoPółRoku);
            this.obgpCzętośćKapitalizacjiOdsetek.Controls.Add(this.obrdbCoRoku);
            this.obgpCzętośćKapitalizacjiOdsetek.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obgpCzętośćKapitalizacjiOdsetek.Location = new System.Drawing.Point(12, 293);
            this.obgpCzętośćKapitalizacjiOdsetek.Name = "obgpCzętośćKapitalizacjiOdsetek";
            this.obgpCzętośćKapitalizacjiOdsetek.Size = new System.Drawing.Size(200, 170);
            this.obgpCzętośćKapitalizacjiOdsetek.TabIndex = 11;
            this.obgpCzętośćKapitalizacjiOdsetek.TabStop = false;
            this.obgpCzętośćKapitalizacjiOdsetek.Text = "Czętość kapitalizacji odsetek m:";
            // 
            // obrdbCoMiesiąc
            // 
            this.obrdbCoMiesiąc.AutoSize = true;
            this.obrdbCoMiesiąc.Location = new System.Drawing.Point(0, 129);
            this.obrdbCoMiesiąc.Name = "obrdbCoMiesiąc";
            this.obrdbCoMiesiąc.Size = new System.Drawing.Size(114, 24);
            this.obrdbCoMiesiąc.TabIndex = 3;
            this.obrdbCoMiesiąc.TabStop = true;
            this.obrdbCoMiesiąc.Text = "Co miesiąc";
            this.obrdbCoMiesiąc.UseVisualStyleBackColor = true;
            // 
            // obrdbCoKwartal
            // 
            this.obrdbCoKwartal.AutoSize = true;
            this.obrdbCoKwartal.Checked = true;
            this.obrdbCoKwartal.Location = new System.Drawing.Point(0, 102);
            this.obrdbCoKwartal.Name = "obrdbCoKwartal";
            this.obrdbCoKwartal.Size = new System.Drawing.Size(109, 24);
            this.obrdbCoKwartal.TabIndex = 2;
            this.obrdbCoKwartal.TabStop = true;
            this.obrdbCoKwartal.Text = "Co kwartal";
            this.obrdbCoKwartal.UseVisualStyleBackColor = true;
            // 
            // obrdbCoPółRoku
            // 
            this.obrdbCoPółRoku.AutoSize = true;
            this.obrdbCoPółRoku.Location = new System.Drawing.Point(0, 75);
            this.obrdbCoPółRoku.Name = "obrdbCoPółRoku";
            this.obrdbCoPółRoku.Size = new System.Drawing.Size(115, 24);
            this.obrdbCoPółRoku.TabIndex = 1;
            this.obrdbCoPółRoku.TabStop = true;
            this.obrdbCoPółRoku.Text = "Co pół roku";
            this.obrdbCoPółRoku.UseVisualStyleBackColor = true;
            // 
            // obrdbCoRoku
            // 
            this.obrdbCoRoku.AutoSize = true;
            this.obrdbCoRoku.Location = new System.Drawing.Point(0, 46);
            this.obrdbCoRoku.Name = "obrdbCoRoku";
            this.obrdbCoRoku.Size = new System.Drawing.Size(105, 24);
            this.obrdbCoRoku.TabIndex = 0;
            this.obrdbCoRoku.TabStop = true;
            this.obrdbCoRoku.Text = "Raz w rok";
            this.obrdbCoRoku.UseVisualStyleBackColor = true;
            // 
            // obdgvTabeleryczneRozliczenieLokaty
            // 
            this.obdgvTabeleryczneRozliczenieLokaty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.obdgvTabeleryczneRozliczenieLokaty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Numerokresulokaty,
            this.Stannapoczątkuokresulokaty,
            this.Odsetkizadanyokreslokaty,
            this.Stannakońcuokresulokaty});
            this.obdgvTabeleryczneRozliczenieLokaty.Location = new System.Drawing.Point(344, 115);
            this.obdgvTabeleryczneRozliczenieLokaty.Name = "obdgvTabeleryczneRozliczenieLokaty";
            this.obdgvTabeleryczneRozliczenieLokaty.RowHeadersWidth = 51;
            this.obdgvTabeleryczneRozliczenieLokaty.RowTemplate.Height = 24;
            this.obdgvTabeleryczneRozliczenieLokaty.Size = new System.Drawing.Size(758, 348);
            this.obdgvTabeleryczneRozliczenieLokaty.TabIndex = 12;
            this.obdgvTabeleryczneRozliczenieLokaty.Visible = false;
            // 
            // Numerokresulokaty
            // 
            this.Numerokresulokaty.HeaderText = "Numer okresu lokaty";
            this.Numerokresulokaty.MinimumWidth = 6;
            this.Numerokresulokaty.Name = "Numerokresulokaty";
            this.Numerokresulokaty.Width = 125;
            // 
            // Stannapoczątkuokresulokaty
            // 
            this.Stannapoczątkuokresulokaty.HeaderText = "Stan na początku okresu lokaty";
            this.Stannapoczątkuokresulokaty.MinimumWidth = 6;
            this.Stannapoczątkuokresulokaty.Name = "Stannapoczątkuokresulokaty";
            this.Stannapoczątkuokresulokaty.Width = 125;
            // 
            // Odsetkizadanyokreslokaty
            // 
            this.Odsetkizadanyokreslokaty.HeaderText = "Odsetki za dany okres lokaty";
            this.Odsetkizadanyokreslokaty.MinimumWidth = 6;
            this.Odsetkizadanyokreslokaty.Name = "Odsetkizadanyokreslokaty";
            this.Odsetkizadanyokreslokaty.Width = 125;
            // 
            // Stannakońcuokresulokaty
            // 
            this.Stannakońcuokresulokaty.HeaderText = "Stan na końcu okresu lokaty";
            this.Stannakońcuokresulokaty.MinimumWidth = 6;
            this.Stannakońcuokresulokaty.Name = "Stannakońcuokresulokaty";
            this.Stannakońcuokresulokaty.Width = 125;
            // 
            // obbtnObliczKnm
            // 
            this.obbtnObliczKnm.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnObliczKnm.Location = new System.Drawing.Point(1120, 181);
            this.obbtnObliczKnm.Name = "obbtnObliczKnm";
            this.obbtnObliczKnm.Size = new System.Drawing.Size(193, 68);
            this.obbtnObliczKnm.TabIndex = 13;
            this.obbtnObliczKnm.Text = "Obliczenie przyszłego stanu konta";
            this.obbtnObliczKnm.UseVisualStyleBackColor = true;
            this.obbtnObliczKnm.Click += new System.EventHandler(this.btnObliczKnm_Click);
            // 
            // obbtnRozliczLokateTabelaryczne
            // 
            this.obbtnRozliczLokateTabelaryczne.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnRozliczLokateTabelaryczne.Location = new System.Drawing.Point(1120, 255);
            this.obbtnRozliczLokateTabelaryczne.Name = "obbtnRozliczLokateTabelaryczne";
            this.obbtnRozliczLokateTabelaryczne.Size = new System.Drawing.Size(193, 71);
            this.obbtnRozliczLokateTabelaryczne.TabIndex = 14;
            this.obbtnRozliczLokateTabelaryczne.Text = "Tabelaryczna wizualizacja\r\n rozliczenia lokaty";
            this.obbtnRozliczLokateTabelaryczne.UseVisualStyleBackColor = true;
            this.obbtnRozliczLokateTabelaryczne.Click += new System.EventHandler(this.btnRozliczLokateTabelaryczne_Click);
            // 
            // obbtnGraficznarozliczenialokaty
            // 
            this.obbtnGraficznarozliczenialokaty.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnGraficznarozliczenialokaty.Location = new System.Drawing.Point(1120, 332);
            this.obbtnGraficznarozliczenialokaty.Name = "obbtnGraficznarozliczenialokaty";
            this.obbtnGraficznarozliczenialokaty.Size = new System.Drawing.Size(193, 70);
            this.obbtnGraficznarozliczenialokaty.TabIndex = 15;
            this.obbtnGraficznarozliczenialokaty.Text = "Graficzna wizualizacja\r\n rozliczenia lokaty";
            this.obbtnGraficznarozliczenialokaty.UseVisualStyleBackColor = true;
            this.obbtnGraficznarozliczenialokaty.Click += new System.EventHandler(this.btnGraficznarozliczenialokaty_Click);
            // 
            // obbtnResetuj
            // 
            this.obbtnResetuj.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnResetuj.Location = new System.Drawing.Point(1120, 408);
            this.obbtnResetuj.Name = "obbtnResetuj";
            this.obbtnResetuj.Size = new System.Drawing.Size(193, 38);
            this.obbtnResetuj.TabIndex = 16;
            this.obbtnResetuj.Text = "Resetuj";
            this.obbtnResetuj.UseVisualStyleBackColor = true;
            this.obbtnResetuj.Click += new System.EventHandler(this.btnResetuj_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // obchtWykres
            // 
            chartArea1.Name = "ChartArea1";
            this.obchtWykres.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.obchtWykres.Legends.Add(legend1);
            this.obchtWykres.Location = new System.Drawing.Point(285, 115);
            this.obchtWykres.Name = "obchtWykres";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.obchtWykres.Series.Add(series1);
            this.obchtWykres.Size = new System.Drawing.Size(825, 348);
            this.obchtWykres.TabIndex = 17;
            this.obchtWykres.Text = "Wykres";
            this.obchtWykres.Visible = false;
            // 
            // obbtnZmieńkolorliniiwykresu
            // 
            this.obbtnZmieńkolorliniiwykresu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnZmieńkolorliniiwykresu.Location = new System.Drawing.Point(526, 486);
            this.obbtnZmieńkolorliniiwykresu.Name = "obbtnZmieńkolorliniiwykresu";
            this.obbtnZmieńkolorliniiwykresu.Size = new System.Drawing.Size(188, 59);
            this.obbtnZmieńkolorliniiwykresu.TabIndex = 18;
            this.obbtnZmieńkolorliniiwykresu.Text = "Wybierz kolor linii wykresu";
            this.obbtnZmieńkolorliniiwykresu.UseVisualStyleBackColor = true;
            this.obbtnZmieńkolorliniiwykresu.Visible = false;
            this.obbtnZmieńkolorliniiwykresu.Click += new System.EventHandler(this.btnZmieńkolorliniiwykresu_Click);
            // 
            // obtbGrubośćlinii
            // 
            this.obtbGrubośćlinii.Location = new System.Drawing.Point(1246, 486);
            this.obtbGrubośćlinii.Maximum = 15;
            this.obtbGrubośćlinii.Name = "obtbGrubośćlinii";
            this.obtbGrubośćlinii.Size = new System.Drawing.Size(176, 56);
            this.obtbGrubośćlinii.TabIndex = 19;
            this.obtbGrubośćlinii.Value = 1;
            this.obtbGrubośćlinii.Visible = false;
            this.obtbGrubośćlinii.Scroll += new System.EventHandler(this.tbGrubośćlinii_Scroll);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obwyjścieToolStripMenuItem,
            this.obtypWykresuToolStripMenuItem,
            this.obstylLiniiWykresuToolStripMenuItem,
            this.obpowrótDoFormularzaKredytówToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1479, 30);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // obwyjścieToolStripMenuItem
            // 
            this.obwyjścieToolStripMenuItem.Name = "obwyjścieToolStripMenuItem";
            this.obwyjścieToolStripMenuItem.Size = new System.Drawing.Size(73, 26);
            this.obwyjścieToolStripMenuItem.Text = "Wyjście";
            this.obwyjścieToolStripMenuItem.Click += new System.EventHandler(this.wyjścieToolStripMenuItem_Click);
            // 
            // obtypWykresuToolStripMenuItem
            // 
            this.obtypWykresuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obkolorLiniiWykresuToolStripMenuItem,
            this.obkolorTłaWykresuToolStripMenuItem});
            this.obtypWykresuToolStripMenuItem.Name = "obtypWykresuToolStripMenuItem";
            this.obtypWykresuToolStripMenuItem.Size = new System.Drawing.Size(102, 26);
            this.obtypWykresuToolStripMenuItem.Text = "Typ wykresu";
            // 
            // obkolorLiniiWykresuToolStripMenuItem
            // 
            this.obkolorLiniiWykresuToolStripMenuItem.Name = "obkolorLiniiWykresuToolStripMenuItem";
            this.obkolorLiniiWykresuToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.obkolorLiniiWykresuToolStripMenuItem.Text = "Kolor linii wykresu";
            this.obkolorLiniiWykresuToolStripMenuItem.Click += new System.EventHandler(this.kolorLiniiWykresuToolStripMenuItem_Click);
            // 
            // obkolorTłaWykresuToolStripMenuItem
            // 
            this.obkolorTłaWykresuToolStripMenuItem.Name = "obkolorTłaWykresuToolStripMenuItem";
            this.obkolorTłaWykresuToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.obkolorTłaWykresuToolStripMenuItem.Text = "kolor tła wykresu";
            this.obkolorTłaWykresuToolStripMenuItem.Click += new System.EventHandler(this.kolorTłaWykresuToolStripMenuItem_Click);
            // 
            // obstylLiniiWykresuToolStripMenuItem
            // 
            this.obstylLiniiWykresuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obkreskowaToolStripMenuItem,
            this.obkreskowoKropkowaDashDotToolStripMenuItem,
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem});
            this.obstylLiniiWykresuToolStripMenuItem.Name = "obstylLiniiWykresuToolStripMenuItem";
            this.obstylLiniiWykresuToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.obstylLiniiWykresuToolStripMenuItem.Text = "Styl linii wykresu";
            // 
            // obkreskowaToolStripMenuItem
            // 
            this.obkreskowaToolStripMenuItem.Name = "obkreskowaToolStripMenuItem";
            this.obkreskowaToolStripMenuItem.Size = new System.Drawing.Size(381, 26);
            this.obkreskowaToolStripMenuItem.Text = "Kreskowa (Dash)";
            this.obkreskowaToolStripMenuItem.Click += new System.EventHandler(this.kreskowaToolStripMenuItem_Click);
            // 
            // obkreskowoKropkowaDashDotToolStripMenuItem
            // 
            this.obkreskowoKropkowaDashDotToolStripMenuItem.Name = "obkreskowoKropkowaDashDotToolStripMenuItem";
            this.obkreskowoKropkowaDashDotToolStripMenuItem.Size = new System.Drawing.Size(381, 26);
            this.obkreskowoKropkowaDashDotToolStripMenuItem.Text = "KreskowoKropkowa(DashDot)";
            this.obkreskowoKropkowaDashDotToolStripMenuItem.Click += new System.EventHandler(this.kreskowoKropkowaDashDotToolStripMenuItem_Click);
            // 
            // obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem
            // 
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem.Name = "obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem";
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem.Size = new System.Drawing.Size(381, 26);
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem.Text = "KreskowoKropkowakropkowa(DashDotDot)";
            this.obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem.Click += new System.EventHandler(this.kreskowoKropkowakropkowaDashDotDotToolStripMenuItem_Click);
            // 
            // obpowrótDoFormularzaKredytówToolStripMenuItem
            // 
            this.obpowrótDoFormularzaKredytówToolStripMenuItem.Name = "obpowrótDoFormularzaKredytówToolStripMenuItem";
            this.obpowrótDoFormularzaKredytówToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.obpowrótDoFormularzaKredytówToolStripMenuItem.Text = "Powrót do formularza kredytów";
            this.obpowrótDoFormularzaKredytówToolStripMenuItem.Click += new System.EventHandler(this.powrótDoFormularzaKredytówToolStripMenuItem_Click);
            // 
            // obbtnZmieńkolortła
            // 
            this.obbtnZmieńkolortła.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnZmieńkolortła.Location = new System.Drawing.Point(720, 485);
            this.obbtnZmieńkolortła.Name = "obbtnZmieńkolortła";
            this.obbtnZmieńkolortła.Size = new System.Drawing.Size(171, 57);
            this.obbtnZmieńkolortła.TabIndex = 21;
            this.obbtnZmieńkolortła.Text = "Wybierz kolor tła wykresu";
            this.obbtnZmieńkolortła.UseVisualStyleBackColor = true;
            this.obbtnZmieńkolortła.Visible = false;
            this.obbtnZmieńkolortła.Click += new System.EventHandler(this.btnZmieńkolortła_Click);
            // 
            // oblblGrubośćlinii
            // 
            this.oblblGrubośćlinii.AutoSize = true;
            this.oblblGrubośćlinii.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblGrubośćlinii.Location = new System.Drawing.Point(1077, 486);
            this.oblblGrubośćlinii.Name = "oblblGrubośćlinii";
            this.oblblGrubośćlinii.Size = new System.Drawing.Size(155, 38);
            this.oblblGrubośćlinii.TabIndex = 22;
            this.oblblGrubośćlinii.Text = "Ustaw grubość linii\r\nwykresu";
            this.oblblGrubośćlinii.Visible = false;
            // 
            // obcmbGrubośćlinii
            // 
            this.obcmbGrubośćlinii.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obcmbGrubośćlinii.FormattingEnabled = true;
            this.obcmbGrubośćlinii.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.obcmbGrubośćlinii.Location = new System.Drawing.Point(913, 485);
            this.obcmbGrubośćlinii.Name = "obcmbGrubośćlinii";
            this.obcmbGrubośćlinii.Size = new System.Drawing.Size(140, 23);
            this.obcmbGrubośćlinii.TabIndex = 24;
            this.obcmbGrubośćlinii.Text = "Wybierz grubość linii";
            this.obcmbGrubośćlinii.Visible = false;
            this.obcmbGrubośćlinii.SelectedIndexChanged += new System.EventHandler(this.cmbGrubośćlinii_SelectedIndexChanged);
            // 
            // oblistbStylliniiwykresu
            // 
            this.oblistbStylliniiwykresu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblistbStylliniiwykresu.FormattingEnabled = true;
            this.oblistbStylliniiwykresu.ItemHeight = 19;
            this.oblistbStylliniiwykresu.Items.AddRange(new object[] {
            "Kreskowa (Dash)",
            "KreskowoKropkowa (DashDot)",
            "KreskowoKropkowakropkowa (DashDotDot)"});
            this.oblistbStylliniiwykresu.Location = new System.Drawing.Point(344, 485);
            this.oblistbStylliniiwykresu.Name = "oblistbStylliniiwykresu";
            this.oblistbStylliniiwykresu.Size = new System.Drawing.Size(160, 80);
            this.oblistbStylliniiwykresu.TabIndex = 25;
            this.oblistbStylliniiwykresu.Visible = false;
            this.oblistbStylliniiwykresu.SelectedIndexChanged += new System.EventHandler(this.listbStylliniiwykresu_SelectedIndexChanged);
            // 
            // oblblStyllinii
            // 
            this.oblblStyllinii.AutoSize = true;
            this.oblblStyllinii.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblStyllinii.Location = new System.Drawing.Point(158, 485);
            this.oblblStyllinii.Name = "oblblStyllinii";
            this.oblblStyllinii.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.oblblStyllinii.Size = new System.Drawing.Size(174, 38);
            this.oblblStyllinii.TabIndex = 26;
            this.oblblStyllinii.Text = "Wybierz (kliknięciem)\r\n styl linii wykresu";
            this.oblblStyllinii.Visible = false;
            // 
            // obbtnPowrótdokokpitu
            // 
            this.obbtnPowrótdokokpitu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnPowrótdokokpitu.Location = new System.Drawing.Point(1120, 51);
            this.obbtnPowrótdokokpitu.Name = "obbtnPowrótdokokpitu";
            this.obbtnPowrótdokokpitu.Size = new System.Drawing.Size(193, 51);
            this.obbtnPowrótdokokpitu.TabIndex = 27;
            this.obbtnPowrótdokokpitu.Text = "Powrót do Kokpitu \r\nprojektu";
            this.obbtnPowrótdokokpitu.UseVisualStyleBackColor = true;
            this.obbtnPowrótdokokpitu.Click += new System.EventHandler(this.btnPowrótdokokpitu_Click);
            // 
            // obLokaty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1479, 619);
            this.Controls.Add(this.obbtnPowrótdokokpitu);
            this.Controls.Add(this.oblblStyllinii);
            this.Controls.Add(this.oblistbStylliniiwykresu);
            this.Controls.Add(this.obcmbGrubośćlinii);
            this.Controls.Add(this.oblblGrubośćlinii);
            this.Controls.Add(this.obbtnZmieńkolortła);
            this.Controls.Add(this.obtbGrubośćlinii);
            this.Controls.Add(this.obbtnZmieńkolorliniiwykresu);
            this.Controls.Add(this.obchtWykres);
            this.Controls.Add(this.obbtnResetuj);
            this.Controls.Add(this.obbtnGraficznarozliczenialokaty);
            this.Controls.Add(this.obbtnRozliczLokateTabelaryczne);
            this.Controls.Add(this.obbtnObliczKnm);
            this.Controls.Add(this.obdgvTabeleryczneRozliczenieLokaty);
            this.Controls.Add(this.obgpCzętośćKapitalizacjiOdsetek);
            this.Controls.Add(this.obcmbRocznaStopaProcentowa);
            this.Controls.Add(this.obtxtKnm);
            this.Controls.Add(this.obtxtn);
            this.Controls.Add(this.obtxtK);
            this.Controls.Add(this.oblblKnm);
            this.Controls.Add(this.oblblRozliczenieTabeleryczne);
            this.Controls.Add(this.oblblWykres);
            this.Controls.Add(this.oblblp);
            this.Controls.Add(this.oblbln);
            this.Controls.Add(this.oblblK);
            this.Controls.Add(this.oblabel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "obLokaty";
            this.Text = "Lokaty";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Lokaty_FormClosing);
            this.obgpCzętośćKapitalizacjiOdsetek.ResumeLayout(false);
            this.obgpCzętośćKapitalizacjiOdsetek.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvTabeleryczneRozliczenieLokaty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obchtWykres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obtbGrubośćlinii)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label oblabel1;
        private System.Windows.Forms.Label oblblK;
        private System.Windows.Forms.Label oblbln;
        private System.Windows.Forms.Label oblblp;
        private System.Windows.Forms.Label oblblWykres;
        private System.Windows.Forms.Label oblblRozliczenieTabeleryczne;
        private System.Windows.Forms.Label oblblKnm;
        private System.Windows.Forms.TextBox obtxtK;
        private System.Windows.Forms.TextBox obtxtn;
        private System.Windows.Forms.TextBox obtxtKnm;
        private System.Windows.Forms.ComboBox obcmbRocznaStopaProcentowa;
        private System.Windows.Forms.GroupBox obgpCzętośćKapitalizacjiOdsetek;
        private System.Windows.Forms.DataGridView obdgvTabeleryczneRozliczenieLokaty;
        private System.Windows.Forms.Button obbtnObliczKnm;
        private System.Windows.Forms.Button obbtnRozliczLokateTabelaryczne;
        private System.Windows.Forms.Button obbtnGraficznarozliczenialokaty;
        private System.Windows.Forms.Button obbtnResetuj;
        private System.Windows.Forms.RadioButton obrdbCoMiesiąc;
        private System.Windows.Forms.RadioButton obrdbCoKwartal;
        private System.Windows.Forms.RadioButton obrdbCoPółRoku;
        private System.Windows.Forms.RadioButton obrdbCoRoku;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numerokresulokaty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stannapoczątkuokresulokaty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Odsetkizadanyokreslokaty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stannakońcuokresulokaty;
        private System.Windows.Forms.DataVisualization.Charting.Chart obchtWykres;
        private System.Windows.Forms.Button obbtnZmieńkolorliniiwykresu;
        private System.Windows.Forms.TrackBar obtbGrubośćlinii;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem obwyjścieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obtypWykresuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obstylLiniiWykresuToolStripMenuItem;
        private System.Windows.Forms.Button obbtnZmieńkolortła;
        private System.Windows.Forms.Label oblblGrubośćlinii;
        private System.Windows.Forms.ComboBox obcmbGrubośćlinii;
        private System.Windows.Forms.Label oblblStyllinii;
        private System.Windows.Forms.ListBox oblistbStylliniiwykresu;
        private System.Windows.Forms.ToolStripMenuItem obkolorLiniiWykresuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obkolorTłaWykresuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obkreskowaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obkreskowoKropkowaDashDotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obkreskowoKropkowakropkowaDashDotDotToolStripMenuItem;
        private System.Windows.Forms.Button obbtnPowrótdokokpitu;
        private System.Windows.Forms.ToolStripMenuItem obpowrótDoFormularzaKredytówToolStripMenuItem;
    }
}

