﻿namespace Projekt2_Babych50635
{
    partial class obKalkulacjadodatkowa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.obbtnFormularzObliczeniaKalkulacji = new System.Windows.Forms.Button();
            this.obbtnPowrótdolokaty = new System.Windows.Forms.Button();
            this.obbtnPowrótdokredytu = new System.Windows.Forms.Button();
            this.obbtnPowrótdokokpitu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // obbtnFormularzObliczeniaKalkulacji
            // 
            this.obbtnFormularzObliczeniaKalkulacji.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnFormularzObliczeniaKalkulacji.Location = new System.Drawing.Point(376, 186);
            this.obbtnFormularzObliczeniaKalkulacji.Name = "obbtnFormularzObliczeniaKalkulacji";
            this.obbtnFormularzObliczeniaKalkulacji.Size = new System.Drawing.Size(304, 139);
            this.obbtnFormularzObliczeniaKalkulacji.TabIndex = 0;
            this.obbtnFormularzObliczeniaKalkulacji.Text = "Formularz Obliczenia Kalkulacji";
            this.obbtnFormularzObliczeniaKalkulacji.UseVisualStyleBackColor = true;
            this.obbtnFormularzObliczeniaKalkulacji.Click += new System.EventHandler(this.obbtnFormularzObliczeniaKalkulacji_Click);
            // 
            // obbtnPowrótdolokaty
            // 
            this.obbtnPowrótdolokaty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnPowrótdolokaty.Location = new System.Drawing.Point(762, 187);
            this.obbtnPowrótdolokaty.Name = "obbtnPowrótdolokaty";
            this.obbtnPowrótdolokaty.Size = new System.Drawing.Size(255, 139);
            this.obbtnPowrótdolokaty.TabIndex = 1;
            this.obbtnPowrótdolokaty.Text = "Formularz Lokaty";
            this.obbtnPowrótdolokaty.UseVisualStyleBackColor = true;
            this.obbtnPowrótdolokaty.Click += new System.EventHandler(this.obbtnPowrótdolokaty_Click);
            // 
            // obbtnPowrótdokredytu
            // 
            this.obbtnPowrótdokredytu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnPowrótdokredytu.Location = new System.Drawing.Point(43, 187);
            this.obbtnPowrótdokredytu.Name = "obbtnPowrótdokredytu";
            this.obbtnPowrótdokredytu.Size = new System.Drawing.Size(268, 139);
            this.obbtnPowrótdokredytu.TabIndex = 2;
            this.obbtnPowrótdokredytu.Text = "Formularz Kredyty";
            this.obbtnPowrótdokredytu.UseVisualStyleBackColor = true;
            this.obbtnPowrótdokredytu.Click += new System.EventHandler(this.obbtnPowrótdokredytu_Click);
            // 
            // obbtnPowrótdokokpitu
            // 
            this.obbtnPowrótdokokpitu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnPowrótdokokpitu.Location = new System.Drawing.Point(1062, 65);
            this.obbtnPowrótdokokpitu.Name = "obbtnPowrótdokokpitu";
            this.obbtnPowrótdokokpitu.Size = new System.Drawing.Size(180, 156);
            this.obbtnPowrótdokokpitu.TabIndex = 3;
            this.obbtnPowrótdokokpitu.Text = "Powrót do\r\n formularza\r\n glównego(kokpitu)";
            this.obbtnPowrótdokokpitu.UseVisualStyleBackColor = true;
            this.obbtnPowrótdokokpitu.Click += new System.EventHandler(this.obbtnPowrótdokokpitu_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(287, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(500, 64);
            this.label1.TabIndex = 4;
            this.label1.Text = " Kalkulacje w zakresie lokat i kredytów\r\n(Autor: Babych i Numer albumu: 50635)";
            // 
            // obKalkulacjadodatkowa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1270, 467);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.obbtnPowrótdokokpitu);
            this.Controls.Add(this.obbtnPowrótdokredytu);
            this.Controls.Add(this.obbtnPowrótdolokaty);
            this.Controls.Add(this.obbtnFormularzObliczeniaKalkulacji);
            this.Name = "obKalkulacjadodatkowa";
            this.Text = "Kalkulacja dodatkowa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.obKalkulacjadodatkowa_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button obbtnFormularzObliczeniaKalkulacji;
        private System.Windows.Forms.Button obbtnPowrótdolokaty;
        private System.Windows.Forms.Button obbtnPowrótdokredytu;
        private System.Windows.Forms.Button obbtnPowrótdokokpitu;
        private System.Windows.Forms.Label label1;
    }
}