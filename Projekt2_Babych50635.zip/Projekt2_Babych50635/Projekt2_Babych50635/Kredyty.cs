﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Projekt2_Babych50635
{
    public partial class obKredyty : Form
    {
        public obKredyty()
        {
            InitializeComponent();
        }

        bool obPobranieDanychWejsciowych(out float obK, out ushort obn, out float obp, out ushort obm)
        {// domyślne ustawienie wartości "Wyjścia"
            obK = 0.0F; obn = 0; obp = 0.0F; obm = 0; 

            // pobieranie danych  
            // pobranie kredytu kapitalowej K
            if (string.IsNullOrEmpty(obtxtKredytuK.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtKredytuK, "ERROR: musisz podać wysokośc lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtKredytuK.Text, out obK))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtKredytuK, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: K >= 100
            if (obK < 100.0F)
            {
                errorProvider1.SetError(obtxtKredytuK, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: K >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie liczby lat kredytu n

            // pobieranie danych  
            // pobranie lat kredytu n
            if (string.IsNullOrEmpty(obtxtnKredytu.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtnKredytu, "ERROR: musisz podać lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!ushort.TryParse(obtxtnKredytu.Text, out obn))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtnKredytu, "ERROR: wystąpił niedozwolony znak w zapisie lizby lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: n >= 1
            if (obn <= 0)
            {
                errorProvider1.SetError(obtxtnKredytu, "ERROR:liczba lat lokaty n musi spełniać warunek wejściowy: n > 0!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // pobranie znakowego zapisu stopy procentowej (bez znaku %)
            if (oblbRocznaStopaProcentowaKredytu.SelectedIndex < 0.000) // == -1
            {
                errorProvider1.SetError(oblbRocznaStopaProcentowaKredytu, "ERROR: musisz wybrać roczna stopę procentową!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            string obRocznaStopa = oblbRocznaStopaProcentowaKredytu.SelectedItem.ToString();
            obRocznaStopa = obRocznaStopa.Trim();

            obRocznaStopa = obRocznaStopa.Substring(0, obRocznaStopa.Length - 1);

            // konwersja na wartość
            if (!float.TryParse(obRocznaStopa, out obp))
            {
                errorProvider1.SetError(oblbRocznaStopaProcentowaKredytu, "ERROR: wystąpił niedozwolony znak w zapisie rocznej stopy procentowej!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // przeliczenia mianowej stopy procentowej na wartość rzeczywistą

            obp = obp / 100;
            // sprawdzenie warunku wejściowego
            if (obp <= 0.00F || obp >= 1.0F)
            {
                errorProvider1.SetError(oblbRocznaStopaProcentowaKredytu, "ERROR: roczna stopa procentowa musi spełniać warunek wejściowy: 0% < p < 100%!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            

            



            // pobranie częstości kapitalizacki odsetek m
            if (obrdbRazWRoku.Checked)
                obm = 1;
            else
           if (obrdbCopółroku.Checked)
                obm = 2;
            else
            if (obrdbCokwartal.Checked)
                obm = 4;
            else
            if (obrdbComiesiąc.Checked)
                obm = 12;
            else
            {
                obm = 1; // domyślnie
                errorProvider1.SetError(obgpLiczbaRatWRokumKredytu, "ERROR: musisz wybrać częstość kapitalizacji odsetek!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd    

            }

      
            return true;

        }
        private void obTabelaryczneRozliczeniekredytuStała(float obK, ushort obn, float obp, ushort obm, out float[,] obTrl)
        {



            //STALA
            obTrl = new float[obn * obm + 1, 4];
            obTrl[0, 0] = 0.0F;
            obTrl[0, 1] = 0.0F;
            obTrl[0, 2] = 0.0F;
            obTrl[0, 3] = obK;

            for (ushort obi = 1; obi < obTrl.GetLength(0); obi++)
            {
                obTrl[obi, 0] = obTrl[obi - 1, 3];
                obTrl[obi, 1] = obTrl[obi, 0] *( obp / obm);
                obTrl[obi, 2] = obK * (((float)Math.Pow(1 + obp / obm, obn * obm) * obp / obm)) / ((float)Math.Pow(1 + obp / obm, obn * obm) - 1) - obTrl[obi, 1];
                obTrl[obi, 3] = obTrl[obi, 0] - obTrl[obi, 2];

            }


        }
        private void obTabelaryczneRozliczeniekredytuMalejąca(float obK, ushort obn, float obp, ushort obm, out float[,] obTrl)
        {
            obTrl = new float[obn * obm + 1, 4];
            obTrl[0, 0] = 0.0F;
            obTrl[0, 1] = 0.0F;
            obTrl[0, 2] = 0.0F;
            obTrl[0, 3] = obK;
            for (ushort obi = 1; obi < obTrl.GetLength(0); obi++)
            {
                obTrl[obi, 0] = obTrl[obi - 1, 3];
                obTrl[obi, 1] = obTrl[obi, 0] * obp / obm;
                obTrl[obi, 2] = (obK / (obn * obm)) + obTrl[obi, 1];
                obTrl[obi, 3] = obTrl[obi, 0] - (obK / (obn * obm));
            }
        }
        private void obTabelaryczneRozliczeniekredytuRosnąca(float obK, ushort obn, float obp, ushort obm, out float[,] obTrl)
        {
            obTrl = new float[obn * obm + 1, 4];
            obTrl[0, 0] = 0.0F;
            obTrl[0, 1] = 0.0F;
            obTrl[0, 2] = 0.0F;
            obTrl[0, 3] = 0.0F;
            for (ushort obi = 1; obi < obTrl.GetLength(0); obi++)
            {
                obTrl[obi, 0] = obTrl[obi - 1, 3];
                obTrl[obi, 1] = obTrl[obi, 0] * obp / obm;
                obTrl[obi, 2] = (obK / (obn * obm)) + obTrl[obi, 1];
                obTrl[obi, 3] = obTrl[obi, 0] + (obK / (obn * obm));
            }
        }


        private void btnTabelarycznerozliczeniekredytu_Click(object sender, EventArgs e)
        {

            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK, obp,obKnm, obRk;

            ushort obn, obm;

            


            if (obrdbStała.Checked)
            { 
            //pobranie danych wejściowych
            if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
            {
                return;
            }
                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();

                

                obRk = (obK / (obn * obm));
                   
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            obtxtRk.Text = obRk.ToString();

            //pobranie danych wejściowych
            if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                return;
            //deklaracja referencyjnej zmiennej tablicowej
            float[,] obTrl;
            // wywolanie metody dla tabelarycznego rozliczenia kredytu
            obTabelaryczneRozliczeniekredytuStała(obK, obn, obp, obm, out obTrl);


            //wpisanie do kontrolki DataGridView danych z tablicy Trl
            for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
            {// dodanie do kontrolki DataGridView nowego wiersza
                obdgvRozliczenieRatyKredytu.Rows.Add();
                // wpisanie (przepisanie) danych z i-tego wiersza tablicy Trl do dodanego wiersza kontrolki DataGridView
                obdgvRozliczenieRatyKredytu.Rows[obi].Cells[0].Value = obi;
                obdgvRozliczenieRatyKredytu.Rows[obi].Cells[1].Value = string.Format("{0:0.00}", obTrl[obi, 0]); //stan na początku i-tego okresu
                obdgvRozliczenieRatyKredytu.Rows[obi].Cells[2].Value = string.Format("{0:0.00}", obTrl[obi, 1]); //odsetki za i-tty okres
                obdgvRozliczenieRatyKredytu.Rows[obi].Cells[3].Value = string.Format("{0:0.00}", obTrl[obi, 2]); //kapital za i-tty okres
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[4].Value = string.Format("{0:0.00}", obTrl[obi, 3]);//stan na końcu i-tego okresu
                    if (obi % 2 == 0)
                    obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.LightGray;
                else
                    obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.White;
            }
                oblblSumabankowarat.Visible = true;
                obtxtKnm.Visible = true;
        }
            else
            if(obrdbMaleące.Checked)
            {
               
                //pobranie danych wejściowych
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {
                    return;
                }
                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();
                

                obRk = (obK / (obn * obm)) ; 
                    
                //deklaracje zminnych dla przechowania pobranych danych wejściowych
                obtxtRk.Text = obRk.ToString();

                //pobranie danych wejściowych
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                    return;
                //deklaracja referencyjnej zmiennej tablicowej
                float[,] obTrl;
                // wywolanie metody dla tabelarycznego rozliczenia kredytu
                obTabelaryczneRozliczeniekredytuMalejąca(obK, obn, obp, obm, out obTrl);


                //wpisanie do kontrolki DataGridView danych z tablicy Trl
                for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
                {// dodanie do kontrolki DataGridView nowego wiersza
                    obdgvRozliczenieRatyKredytu.Rows.Add();
                    // wpisanie (przepisanie) danych z i-tego wiersza tablicy Trl do dodanego wiersza kontrolki DataGridView
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[0].Value = obi;
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[1].Value = string.Format("{0:0.00}", obTrl[obi, 0]); //stan na początku i-tego okresu
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[2].Value = string.Format("{0:0.00}", obTrl[obi, 1]); //odsetki za i-tty okres
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[3].Value = string.Format("{0:0.00}", obTrl[obi, 2]); //kapital za i-tty okres
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[4].Value = string.Format("{0:0.00}", obTrl[obi, 3]);//stan na końcu i-tego okresu
                    if (obi % 2 == 0)
                        obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.LightGray;
                    else
                        obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.White;
                }
                oblblSumabankowarat.Visible = true;
                obtxtKnm.Visible = true;
            }
            if(obrdbRośne.Checked)
            {
                //pobranie danych wejściowych
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {
                    return;
                }
                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();


                obRk = (obK / (obn * obm));
                     
                //deklaracje zminnych dla przechowania pobranych danych wejściowych
                obtxtRk.Text = obRk.ToString();

                //pobranie danych wejściowych
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                    return;
                //deklaracja referencyjnej zmiennej tablicowej
                float[,] obTrl;
                // wywolanie metody dla tabelarycznego rozliczenia kredytu
                obTabelaryczneRozliczeniekredytuRosnąca(obK, obn, obp, obm, out obTrl);


                //wpisanie do kontrolki DataGridView danych z tablicy Trl
                for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
                {// dodanie do kontrolki DataGridView nowego wiersza
                    obdgvRozliczenieRatyKredytu.Rows.Add();
                    // wpisanie (przepisanie) danych z i-tego wiersza tablicy Trl do dodanego wiersza kontrolki DataGridView
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[0].Value = obi;
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[1].Value = string.Format("{0:0.00}", obTrl[obi, 0]); //stan na początku i-tego okresu
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[2].Value = string.Format("{0:0.00}", obTrl[obi, 1]); //odsetki za i-tty okres
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[3].Value = string.Format("{0:0.00}", obTrl[obi, 2]); //kapital za i-tty okres
                    obdgvRozliczenieRatyKredytu.Rows[obi].Cells[4].Value = string.Format("{0:0.00}", obTrl[obi, 3]);//stan na końcu i-tego okresu
                    if (obi % 2 == 0)
                        obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.LightGray;
                    else
                        obdgvRozliczenieRatyKredytu.Rows[obi].DefaultCellStyle.BackColor = Color.White;
                }
                oblblSumabankowarat.Visible = true;
                obtxtKnm.Visible = true;
            }
            obdgvRozliczenieRatyKredytu.RowTemplate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //odsłonięcie kontrolek tabelarycznej wizualizacji rozliczenia kredytu
            tbTabelarycznerozliczeniekredytu.Show();
        }

        private void btnPowrótdoLokat_Click(object sender, EventArgs e)
        {
            obLokaty obt = new obLokaty();
            obt.Show();
            Hide();
        }

        private void wyjścieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();
                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                     "zdarzenia było:" + ")");


                    break;

            }

        }

        private void powrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obKokpitprojektukalkulacjifinansowych obk = new obKokpitprojektukalkulacjifinansowych();
            obk.Show();
            Hide();
        }

        private void powrótDoFormularzaLokatyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            obLokaty obo = new obLokaty();
            obo.Show();
            Hide();
        }

        private void Kredyty_FormClosing(object sender, FormClosingEventArgs obe)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
                MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
                this.Text,
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason + ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }

        }

        private void btnGraficznerozliczeniekredytu_Click(object sender, EventArgs e)
        {
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK,obKnm, obR, obp;
            ushort obn, obm;
            
            //pobranie danych wejściowych
            if (obrdbStała.Checked)
            {
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {


                    return;

                }
                
                obR = obK * (((float)Math.Pow(1 + obp / obm, obn * obm) * obp / obm)) / ((float)Math.Pow(1 + obp / obm, obn * obm) - 1);
                 



                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();

                //deklaracja referencyjnej zmiennej tablicowej
                float[,] obTrl;
                // wywolanie metody dla tabelarycznego rozliczenia lokaty
                obTabelaryczneRozliczeniekredytuStała(obK, obn, obp, obm, out obTrl);
                // sformatowanie kontrolki Chart
                // zerowanie serii danych kontrolki Chart
                obchtWykres.Series.Clear();
                // dodanie nowej serii danych
                obchtWykres.Series.Add("Trl[i, 1]");
                obchtWykres.Series.Add("Trl[i, 2]");
                obchtWykres.Series.Add("Trl[i, 1]+Trl[i, 2]");


                // opisanie osi układu współrzednych
                obchtWykres.ChartAreas[0].AxisX.Title = "Numer raty";
                obchtWykres.ChartAreas[0].AxisX.Minimum = 0;
                obchtWykres.ChartAreas[0].AxisX.Interval = 2;
                obchtWykres.ChartAreas[0].AxisY.Title = "Wysokość raty kapitalowej Rk, raty odsetkowej Ro i ich rata lączna R";
                obchtWykres.ChartAreas[0].AxisY.Minimum = 0;
               
                obchtWykres.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[2].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                

                // uwidocznienie legendy wykresu
                obchtWykres.Series[0].IsVisibleInLegend = true;
                obchtWykres.Series[0].Name = "Rk";
                obchtWykres.Series[1].IsVisibleInLegend = true;
                obchtWykres.Series[1].Name = "Ro";
                obchtWykres.Series[2].IsVisibleInLegend = true;
                obchtWykres.Series[2].Name = "R = Ro + Rk";
                obchtWykres.Series[1].BorderWidth = 2;
                obchtWykres.Series[0].BorderWidth = 2;
               
                for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
                {

                    obchtWykres.Series[0].Points.AddXY(obi, obTrl[obi, 1]);
                    obchtWykres.Series[1].Points.AddXY(obi, obTrl[obi, 2]);
                    obchtWykres.Series[2].Points.AddXY(obi, obR);
                }
                obchtWykres.Series[1].BorderDashStyle = ChartDashStyle.Dash;
                obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDot;
                obchtWykres.Series[2].BorderWidth = 4;

                oblblGrafikStały.Visible = true;
                oblblGrafikRosnący.Visible = false;
                oblblGrafikMalejący.Visible = false;
            }
            else
                if(obrdbMaleące.Checked)
            {
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {


                    return;

                }
                
                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();

                //deklaracja referencyjnej zmiennej tablicowej
                float[,] obTrl;
                // wywolanie metody dla tabelarycznego rozliczenia lokaty
                obTabelaryczneRozliczeniekredytuMalejąca(obK, obn, obp, obm, out obTrl);
                // sformatowanie kontrolki Chart

                // zerowanie serii danych kontrolki ChartchtWykres.Series.Clear();
                // dodanie nowej serii danych
                obchtWykres.Series.Clear();
                // dodanie nowej serii danych
                obchtWykres.Series.Add("Trl[i, 1]");
                obchtWykres.Series.Add("Trl[i, 2]");
                obchtWykres.Series.Add("Trl[i, 1]+Trl[i, 2]");


                // opisanie osi układu współrzednych
                obchtWykres.ChartAreas[0].AxisX.Title = "Numer raty";
                obchtWykres.ChartAreas[0].AxisX.Minimum = 0;
                obchtWykres.ChartAreas[0].AxisX.Interval = 2;
                obchtWykres.ChartAreas[0].AxisY.Title = "Wysokość raty kapitalowej Rk, raty odsetkowej Ro i ich rata lączna R";
                obchtWykres.ChartAreas[0].AxisY.Minimum = 0;

                obchtWykres.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[2].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

                // uwidocznienie legendy wykresu
                obchtWykres.Series[0].IsVisibleInLegend = true;
                obchtWykres.Series[0].Name = "Rk";
                obchtWykres.Series[1].IsVisibleInLegend = true;
                obchtWykres.Series[1].Name = "Ro";
                obchtWykres.Series[2].IsVisibleInLegend = true;
                obchtWykres.Series[2].Name = "R = Ro + Rk";
                obchtWykres.Series[1].BorderWidth = 2;
                obchtWykres.Series[0].BorderWidth = 2;
                obchtWykres.Series[2].BorderWidth = 2;
                for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
                {

                    obchtWykres.Series[0].Points.AddXY(obi, obTrl[obi, 1] );
                    obchtWykres.Series[2].Points.AddXY(obi, obTrl[obi, 1]+ obTrl[obi, 2]);
                    obchtWykres.Series[1].Points.AddXY(obi, obTrl[obi, 2]);
                }
                obchtWykres.Series[1].BorderDashStyle = ChartDashStyle.Dash;
                obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDot;
                obchtWykres.Series[2].BorderWidth = 4;
                oblblGrafikMalejący.Visible = true;
                oblblGrafikStały.Visible = false;
                oblblGrafikRosnący.Visible = false;

            }
            else
                if(obrdbRośne.Checked)
            {
                if (!obPobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {


                    return;

                }
                obR = obK * (((float)Math.Pow(1 + obp / obm, obn * obm) * obp / obm)) / ((float)Math.Pow(1 + obp / obm, obn * obm) - 1);
                obKnm = obK * ((float)Math.Pow(1 + obp / obm, obn * obm));
                obtxtKnm.Text = obKnm.ToString();

                //deklaracja referencyjnej zmiennej tablicowej
                float[,] obTrl;
                // wywolanie metody dla tabelarycznego rozliczenia lokaty
                obTabelaryczneRozliczeniekredytuRosnąca(obK, obn, obp, obm, out obTrl);
                // sformatowanie kontrolki Chart
                // zerowanie serii danych kontrolki Chart
                obchtWykres.Series.Clear();
                // dodanie nowej serii danych
                obchtWykres.Series.Add("Trl[i, 1]");
                obchtWykres.Series.Add("Trl[i, 2]");
                obchtWykres.Series.Add("Trl[i, 1]+Trl[i, 2]");


                // opisanie osi układu współrzednych
                obchtWykres.ChartAreas[0].AxisX.Title = "Numer raty";
                obchtWykres.ChartAreas[0].AxisX.Minimum = 0;
                obchtWykres.ChartAreas[0].AxisX.Interval = 2;
                obchtWykres.ChartAreas[0].AxisY.Title = "Wysokość raty kapitalowej Rk, raty odsetkowej Ro i ich rata lączna R";
                obchtWykres.ChartAreas[0].AxisY.Minimum = 0;

                obchtWykres.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[1].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                obchtWykres.Series[2].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

                // uwidocznienie legendy wykresu
                obchtWykres.Series[0].IsVisibleInLegend = true;
                obchtWykres.Series[0].Name = "Rk";
                obchtWykres.Series[1].IsVisibleInLegend = true;
                obchtWykres.Series[1].Name = "Ro";
                obchtWykres.Series[2].IsVisibleInLegend = true;
                obchtWykres.Series[2].Name = "R = Ro + Rk";
                obchtWykres.Series[1].BorderWidth = 2;
                obchtWykres.Series[0].BorderWidth = 2;
                obchtWykres.Series[2].BorderWidth = 2;
                for (ushort obi = 0; obi < obTrl.GetLength(0); obi++)
                {

                    obchtWykres.Series[0].Points.AddXY(obi, obTrl[obi, 1]);
                    obchtWykres.Series[2].Points.AddXY(obi, obTrl[obi, 1] + obTrl[obi, 2]);
                    obchtWykres.Series[1].Points.AddXY(obi, obTrl[obi, 2]);
                }
               
                oblblGrafikRosnący.Visible = true;
                oblblGrafikMalejący.Visible = false;
                oblblGrafikStały.Visible = false;
            }
            obchtWykres.Series[1].BorderDashStyle = ChartDashStyle.Dash;
            obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDot;
            obchtWykres.Series[2].BorderWidth = 4;


            // odsłonięcie kontrolek
            obchtWykres.Visible = true;

            obchtWykres.Enabled = true;
            oblblSumabankowarat.Visible = true;
            obtxtKnm.Visible = true;

        }

        private void btnResetujkredytu_Click(object sender, EventArgs e)
        {
            obtxtKredytuK.Clear();
            obtxtKredytuK.Enabled = true;
            obtxtnKredytu.Text = "";
            obtxtnKredytu.Enabled = true;
            oblbRocznaStopaProcentowaKredytu.ClearSelected();
            obgpLiczbaRatWRokumKredytu.Enabled = true;
            obgpSpłatakredytuwlatach.Enabled = true;
            obrdbCokwartal.Checked = true;
            obrdbMaleące.Checked = true;
            obtxtKnm.Visible = false;
            oblblSumabankowarat.Visible = false;
            obtxtKnm.Clear();
            obtxtRk.Clear();
            obdgvRozliczenieRatyKredytu.Rows.Clear();
            obchtWykres.Series.Clear();
            oblblGrafikMalejący.Visible = false;
            oblblGrafikRosnący.Visible = false;
            oblblGrafikStały.Visible = false;

                

        }

        
    }
}
