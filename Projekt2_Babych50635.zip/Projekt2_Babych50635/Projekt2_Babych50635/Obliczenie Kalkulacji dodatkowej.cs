﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt2_Babych50635
{
    public partial class obObliczenieKalkulacjidodatkowej : Form
    {
        public obObliczenieKalkulacjidodatkowej()
        {
            InitializeComponent();
        }
        bool obPobranieDanychWejsciowych(out float obKnm, out ushort obn, out float obp, out ushort obm)
        {// domyślne ustawienie wartości "Wyjścia"
            obKnm = 0.0F; obn = 0; obp = 0.0F; obm = 0;

            // pobieranie danych  
            // pobranie lokaty kapitalowej Knm
            if (string.IsNullOrEmpty(obtxtKnm.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtKnm, "ERROR: musisz podać wysokośc lokaty Knm!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtKnm.Text, out obKnm))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtKnm, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty Knm!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obKnm >= 100
            if (obKnm < 100.0F)
            {
                errorProvider1.SetError(obtxtKnm, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: Knm >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie liczby lat lokaty obn

            // pobieranie danych  
            // pobranie lat lokaty obn
            if (string.IsNullOrEmpty(obtxtn.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtn, "ERROR: musisz podać lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!ushort.TryParse(obtxtn.Text, out obn))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtn, "ERROR: wystąpił niedozwolony znak w zapisie lizby lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obn >= 1
            if (obn <= 0)
            {
                errorProvider1.SetError(obtxtn, "ERROR:liczba lat lokaty n musi spełniać warunek wejściowy: n > 0!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // pobranie znakowego zapisu stopy procentowej (bez znaku %)




            // pobranie rocznej stopy procentowej
            // czy użytkownik wybrał jakąś stopy procentowej

            if (obcmbRocznaStopaProcentowa.SelectedIndex < 0.000) // == -1
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: musisz wybrać roczna stopę procentową!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            string obRocznaStopa = obcmbRocznaStopaProcentowa.SelectedItem.ToString();
            obRocznaStopa = obRocznaStopa.Trim();

            obRocznaStopa = obRocznaStopa.Substring(0, obRocznaStopa.Length - 1);

            // konwersja na wartość
            if (!float.TryParse(obRocznaStopa, out obp))
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: wystąpił niedozwolony znak w zapisie rocznej stopy procentowej!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // przeliczenia mianowej stopy procentowej na wartość rzeczywistą

            obp = obp / 100;
            // sprawdzenie warunku wejściowego
            if (obp <= 0.00F || obp >= 1.0F)
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: roczna stopa procentowa musi spełniać warunek wejściowy: 0% < p < 100%!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie częstości kapitalizacki odsetek m
            if (obrdbCoRoku.Checked)
                obm = 1;
            else
           if (obrdbCoPółRoku.Checked)
                obm = 2;
            else
            if (obrdbCoKwartal.Checked)
                obm = 4;
            else
            if (obrdbCoMiesiąc.Checked)
                obm = 12;
            else
            {
                obm = 1; // domyślnie
                errorProvider1.SetError(obgpCzętośćKapitalizacjiOdsetek, "ERROR: musisz wybrać częstość kapitalizacji odsetek!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd    

            }
            return true;

        }

        bool obPobranieDanychWejsciowych2(out float obK2, out ushort obn2, out float obKnm2, out ushort obm)
        {// domyślne ustawienie wartości "Wyjścia"
            obK2 = 0.0F; obn2 = 0; obKnm2 = 0.0F; obm = 0;

            // pobieranie danych  
            // pobranie lokaty kapitalowej K
            if (string.IsNullOrEmpty(obtxtK2.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtK2, "ERROR: musisz podać wysokośc lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtK2.Text, out obK2))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtK2, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obK >= 100
            if (obK2 < 100.0F)
            {
                errorProvider1.SetError(obtxtK2, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: K >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            // pobieranie danych  
            // pobranie lokaty kapitalowej Knm2
            if (string.IsNullOrEmpty(obtxtKnm2.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtKnm2, "ERROR: musisz podać wysokośc lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtKnm2.Text, out obKnm2))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtKnm2, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obKnm2 >= 100
            if (obKnm2 < 100.0F)
            {
                errorProvider1.SetError(obtxtKnm2, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: K >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie liczby lat lokaty obn

            // pobieranie danych  
            // pobranie lat lokaty obn
            if (string.IsNullOrEmpty(obtxtn2.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtn2, "ERROR: musisz podać lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!ushort.TryParse(obtxtn2.Text, out obn2))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtn2, "ERROR: wystąpił niedozwolony znak w zapisie lizby lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obn >= 1
            if (obn2 <= 0)
            {
                errorProvider1.SetError(obtxtn2, "ERROR:liczba lat lokaty n musi spełniać warunek wejściowy: n > 0!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // pobranie znakowego zapisu stopy procentowej (bez znaku %)




           

            // pobranie częstości kapitalizacki odsetek m
            if (obrdbCoRoku2.Checked)
                obm = 1;
            else
           if (obrdbCoPółRoku2.Checked)
                obm = 2;
            else
            if (obrdbCoKwartal2.Checked)
                obm = 4;
            else
            if (obrdbCoMiesiąc2.Checked)
                obm = 12;
            else
            {
                obm = 1; // domyślnie
                errorProvider1.SetError(obgpCzętośćKapitalizacjiOdsetek2, "ERROR: musisz wybrać częstość kapitalizacji odsetek!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd    

            }
            return true;

        }
        bool obPobranieDanychWejsciowych3(out float obK3, out ushort obKnm3, out float obp2, out ushort obm3)
        {// domyślne ustawienie wartości "Wyjścia"
            obK3 = 0.0F; obKnm3 = 0; obp2 = 0.0F; obm3 = 0;

            // pobieranie danych  
            // pobranie lokaty kapitalowej K
            if (string.IsNullOrEmpty(obtxtK3.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtK3, "ERROR: musisz podać wysokośc lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtK3.Text, out obK3))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtK3, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obK >= 100
            if (obK3 < 100.0F)
            {
                errorProvider1.SetError(obtxtK3, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: K >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie liczby lat lokaty obn

            // pobieranie danych  
            // pobranie lat lokaty obn
            if (string.IsNullOrEmpty(obtxtKnm3.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtKnm3, "ERROR: musisz podać lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!ushort.TryParse(obtxtKnm3.Text, out obKnm3))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtKnm3, "ERROR: wystąpił niedozwolony znak w zapisie lizby lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obn >= 1
            if (obKnm3 <= 0)
            {
                errorProvider1.SetError(obtxtKnm3, "ERROR:liczba lat lokaty n musi spełniać warunek wejściowy: n > 0!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // pobranie znakowego zapisu stopy procentowej (bez znaku %)




            // pobranie rocznej stopy procentowej
            // czy użytkownik wybrał jakąś stopy procentowej

            if (obcmbRocznaStopaProcentowa2.SelectedIndex < 0.000) // == -1
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa2, "ERROR: musisz wybrać roczna stopę procentową!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            string obRocznaStopa2 = obcmbRocznaStopaProcentowa2.SelectedItem.ToString();
            obRocznaStopa2 = obRocznaStopa2.Trim();

            obRocznaStopa2 = obRocznaStopa2.Substring(0, obRocznaStopa2.Length - 1);

            // konwersja na wartość
            if (!float.TryParse(obRocznaStopa2, out obp2))
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa2, "ERROR: wystąpił niedozwolony znak w zapisie rocznej stopy procentowej!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // przeliczenia mianowej stopy procentowej na wartość rzeczywistą

            obp2 = obp2 / 100;
            // sprawdzenie warunku wejściowego
            if (obp2 <= 0.00F || obp2 >= 1.0F)
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa2, "ERROR: roczna stopa procentowa musi spełniać warunek wejściowy: 0% < p < 100%!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie częstości kapitalizacki odsetek m
            if (obrdbCoRoku3.Checked)
                obm3 = 1;
            else
           if (obrdbCoPółRoku3.Checked)
                obm3 = 2;
            else
            if (obrdbCoKwartal3.Checked)
                obm3 = 4;
            else
            if (obrdbCoMiesiąc3.Checked)
                obm3 = 12;
            else
            {
                obm3 = 1; // domyślnie
                errorProvider1.SetError(obgpCzętośćKapitalizacjiOdsetek3, "ERROR: musisz wybrać częstość kapitalizacji odsetek!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd    

            }
            return true;

        }

        private void obbtnZnajdżK_Click(object sender, EventArgs obe)
        {
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK, obKnm, obp;
            ushort obn, obm;
            //pobranie danych wejściowych
            if (!obPobranieDanychWejsciowych(out obKnm, out obn, out obp, out obm))
            {
                return;
            }

            obK = obKnm * (float)Math.Pow(1 + obp / obm, obn * obm);
            obtxtK.Visible = true;
            obtxtK.Text = obK.ToString();
        }

        private void obbtnZnajdżp_Click(object sender, EventArgs obe)
        {
            
                //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK2, obKnm2, obp;
            ushort obn2, obm;
            //pobranie danych wejściowych
            if (!obPobranieDanychWejsciowych2(out obKnm2, out obn2, out obK2, out obm))
            {
                return;
            }
            obp = obm * (obKnm2 - (float)Math.Pow(obK2, 1/(obn2*obm)))/100;
           
            obtxtp.Visible = true;
            obtxtp.Text = obp.ToString();
        }

        private void obbtnLiczbalatn_Click(object sender, EventArgs e)
        {
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK3, obKnm3, obn3;
            ushort obp2, obm3;
            //pobranie danych wejściowych
            if (!obPobranieDanychWejsciowych3(out obKnm3, out obp2, out obK3, out obm3))
            {
                return;
            }
            obn3 = ((float)Math.Log(obKnm3 / obK3, Math.Pow(1+(obp2/obm3),obm3)));
            obtxtn3.Text = string.Format("{0:0}", obn3);
            
            obtxtn3.Visible = true;
            obtxtn3.Text = obn3.ToString();
        }

        private void obObliczenieKalkulacjidodatkowej_FormClosing(object sender, FormClosingEventArgs obe)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNoCancel,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason + ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }
        }

        private void obbtnPowrótdokalkulacjidodatkowej_Click(object sender, EventArgs e)
        {
            obKokpitprojektukalkulacjifinansowych obt = new obKokpitprojektukalkulacjifinansowych();
            obt.Show();//link do formularza kredytu
            Hide();
        }

        private void obbtnPowrótdokokpitu_Click(object sender, EventArgs e)
        {
            obKokpitprojektukalkulacjifinansowych obl = new obKokpitprojektukalkulacjifinansowych();
            obl.Show();//link do formularza kredytu
            Hide();
        }
    }
}
