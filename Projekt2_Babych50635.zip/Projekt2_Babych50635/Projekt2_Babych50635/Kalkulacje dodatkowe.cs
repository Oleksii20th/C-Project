﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt2_Babych50635
{
    public partial class obKalkulacjadodatkowa : Form
    {
        public obKalkulacjadodatkowa()
        {
            InitializeComponent();
        }

        private void obbtnFormularzObliczeniaKalkulacji_Click(object sender, EventArgs obe)
        {

            obObliczenieKalkulacjidodatkowej obt = new obObliczenieKalkulacjidodatkowej();
            obt.Show();
            Hide();
        }

        private void obKalkulacjadodatkowa_FormClosing(object sender, FormClosingEventArgs obe)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNoCancel,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason + ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }
        }

        private void obbtnPowrótdolokaty_Click(object sender, EventArgs e)
        {
            obLokaty obn = new obLokaty();
            obn.Show();//link do formularza lokaty
            Hide();
        }

        private void obbtnPowrótdokredytu_Click(object sender, EventArgs e)
        {
            obKredyty obk = new obKredyty();
            obk.Show();//link do formularza kredytu
            Hide();
        }

        private void obbtnPowrótdokokpitu_Click(object sender, EventArgs e)
        {
            obKalkulacjadodatkowa obl = new obKalkulacjadodatkowa();
            obl.Show();//link do formularza kredytu
            Hide();
        }
    }
}
