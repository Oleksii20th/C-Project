﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt2_Babych50635
{
    public partial class obKokpitprojektukalkulacjifinansowych : Form
    {
        
        public obKokpitprojektukalkulacjifinansowych()
        {
            InitializeComponent();
        }

        private void btnRozliczanielokatkapitalowych_Click(object sender, EventArgs obe)
        {
            
            obLokaty obn = new obLokaty();
            obn.Show();//link do formularza lokaty
            Hide();

        }

        private void btnRozliczaniekredytów_Click(object sender, EventArgs obe)
        {
            obKredyty obk = new obKredyty();
            obk.Show();//link do formularza kredytu
            Hide();

        }

        private void Kokpitprojektukalkulacjifinansowych_FormClosing(object sender, FormClosingEventArgs obe)
        {

            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNoCancel,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason + ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }
       }

        private void obKalkulacjadodatkowa_Click(object sender, EventArgs e)
        {
            obKalkulacjadodatkowa obt = new obKalkulacjadodatkowa();
            obt.Show();
            Hide();
        }

        private void oblblKalkulacjefinansowe_Click(object sender, EventArgs e)
        {

        }
    }
}
