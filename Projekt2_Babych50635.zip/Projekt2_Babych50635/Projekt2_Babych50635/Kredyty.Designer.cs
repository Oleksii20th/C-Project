﻿namespace Projekt2_Babych50635
{
    partial class obKredyty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series13 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series14 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series15 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.obpanel1 = new System.Windows.Forms.Panel();
            this.oblblSumabankowarat = new System.Windows.Forms.Label();
            this.obtxtKnm = new System.Windows.Forms.TextBox();
            this.oblbRocznaStopaProcentowaKredytu = new System.Windows.Forms.ListBox();
            this.obbtnGraficznerozliczeniekredytu = new System.Windows.Forms.Button();
            this.obbtnResetujkredytu = new System.Windows.Forms.Button();
            this.obbtnTabelarycznerozliczeniekredytu = new System.Windows.Forms.Button();
            this.obgpSpłatakredytuwlatach = new System.Windows.Forms.GroupBox();
            this.obrdbRośne = new System.Windows.Forms.RadioButton();
            this.obrdbMaleące = new System.Windows.Forms.RadioButton();
            this.obrdbStała = new System.Windows.Forms.RadioButton();
            this.obgpLiczbaRatWRokumKredytu = new System.Windows.Forms.GroupBox();
            this.obrdbComiesiąc = new System.Windows.Forms.RadioButton();
            this.obrdbCokwartal = new System.Windows.Forms.RadioButton();
            this.obrdbCopółroku = new System.Windows.Forms.RadioButton();
            this.obrdbRazWRoku = new System.Windows.Forms.RadioButton();
            this.oblblRocznaStopaProcentowaKredytu = new System.Windows.Forms.Label();
            this.obtxtnKredytu = new System.Windows.Forms.TextBox();
            this.obtxtKredytuK = new System.Windows.Forms.TextBox();
            this.oblblnKredytu = new System.Windows.Forms.Label();
            this.oblblKkredytu = new System.Windows.Forms.Label();
            this.obbtnPowrótdoLokat = new System.Windows.Forms.Button();
            this.obmenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.obfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obwyjścieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obpowrótDoFormularzaLokatyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obtbkredytu = new System.Windows.Forms.TabControl();
            this.obtbPulpitrozliczeniakredytu = new System.Windows.Forms.TabPage();
            this.tbTabelarycznerozliczeniekredytu = new System.Windows.Forms.TabPage();
            this.obpanel2 = new System.Windows.Forms.Panel();
            this.obdgvRozliczenieRatyKredytu = new System.Windows.Forms.DataGridView();
            this.Numerraty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stanzadłużeniaprzedpłaceniemjtejraty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WysokośćratyodsetkowejRo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WysokośćratykapitalowejRk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stanzadłużeniapowpłaceniujtejraty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obtxtRk = new System.Windows.Forms.TextBox();
            this.oblabel1 = new System.Windows.Forms.Label();
            this.tbGraficznerozliczeniekredytu = new System.Windows.Forms.TabPage();
            this.obpanel3 = new System.Windows.Forms.Panel();
            this.oblblGrafikMalejący = new System.Windows.Forms.Label();
            this.oblblGrafikRosnący = new System.Windows.Forms.Label();
            this.oblblGrafikStały = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.obchtWykres = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.obpanel1.SuspendLayout();
            this.obgpSpłatakredytuwlatach.SuspendLayout();
            this.obgpLiczbaRatWRokumKredytu.SuspendLayout();
            this.obmenuStrip1.SuspendLayout();
            this.obtbkredytu.SuspendLayout();
            this.obtbPulpitrozliczeniakredytu.SuspendLayout();
            this.tbTabelarycznerozliczeniekredytu.SuspendLayout();
            this.obpanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvRozliczenieRatyKredytu)).BeginInit();
            this.tbGraficznerozliczeniekredytu.SuspendLayout();
            this.obpanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obchtWykres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // obpanel1
            // 
            this.obpanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.obpanel1.Controls.Add(this.oblblSumabankowarat);
            this.obpanel1.Controls.Add(this.obtxtKnm);
            this.obpanel1.Controls.Add(this.oblbRocznaStopaProcentowaKredytu);
            this.obpanel1.Controls.Add(this.obbtnGraficznerozliczeniekredytu);
            this.obpanel1.Controls.Add(this.obbtnResetujkredytu);
            this.obpanel1.Controls.Add(this.obbtnTabelarycznerozliczeniekredytu);
            this.obpanel1.Controls.Add(this.obgpSpłatakredytuwlatach);
            this.obpanel1.Controls.Add(this.obgpLiczbaRatWRokumKredytu);
            this.obpanel1.Controls.Add(this.oblblRocznaStopaProcentowaKredytu);
            this.obpanel1.Controls.Add(this.obtxtnKredytu);
            this.obpanel1.Controls.Add(this.obtxtKredytuK);
            this.obpanel1.Controls.Add(this.oblblnKredytu);
            this.obpanel1.Controls.Add(this.oblblKkredytu);
            this.obpanel1.Location = new System.Drawing.Point(3, 0);
            this.obpanel1.Name = "obpanel1";
            this.obpanel1.Size = new System.Drawing.Size(1066, 463);
            this.obpanel1.TabIndex = 0;
            // 
            // oblblSumabankowarat
            // 
            this.oblblSumabankowarat.AutoSize = true;
            this.oblblSumabankowarat.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblSumabankowarat.Location = new System.Drawing.Point(731, 153);
            this.oblblSumabankowarat.Name = "oblblSumabankowarat";
            this.oblblSumabankowarat.Size = new System.Drawing.Size(235, 57);
            this.oblblSumabankowarat.TabIndex = 15;
            this.oblblSumabankowarat.Text = "Suma bankowa \r\nrat spaty kredytu\r\n(z doliczaniem okresie lokaty):";
            this.oblblSumabankowarat.Visible = false;
            // 
            // obtxtKnm
            // 
            this.obtxtKnm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obtxtKnm.Location = new System.Drawing.Point(735, 213);
            this.obtxtKnm.Name = "obtxtKnm";
            this.obtxtKnm.ReadOnly = true;
            this.obtxtKnm.Size = new System.Drawing.Size(224, 27);
            this.obtxtKnm.TabIndex = 14;
            this.obtxtKnm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.obtxtKnm.Visible = false;
            // 
            // oblbRocznaStopaProcentowaKredytu
            // 
            this.oblbRocznaStopaProcentowaKredytu.FormattingEnabled = true;
            this.oblbRocznaStopaProcentowaKredytu.ItemHeight = 16;
            this.oblbRocznaStopaProcentowaKredytu.Items.AddRange(new object[] {
            "10,00%",
            "11,00%",
            "12,00%",
            "12,50%",
            "13,00%",
            "14,00%",
            "15,00%"});
            this.oblbRocznaStopaProcentowaKredytu.Location = new System.Drawing.Point(637, 61);
            this.oblbRocznaStopaProcentowaKredytu.Name = "oblbRocznaStopaProcentowaKredytu";
            this.oblbRocznaStopaProcentowaKredytu.Size = new System.Drawing.Size(120, 68);
            this.oblbRocznaStopaProcentowaKredytu.TabIndex = 13;
            // 
            // obbtnGraficznerozliczeniekredytu
            // 
            this.obbtnGraficznerozliczeniekredytu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnGraficznerozliczeniekredytu.Location = new System.Drawing.Point(567, 359);
            this.obbtnGraficznerozliczeniekredytu.Name = "obbtnGraficznerozliczeniekredytu";
            this.obbtnGraficznerozliczeniekredytu.Size = new System.Drawing.Size(366, 57);
            this.obbtnGraficznerozliczeniekredytu.TabIndex = 11;
            this.obbtnGraficznerozliczeniekredytu.Text = "Graficzna prezentacja spłaty kredytu";
            this.obbtnGraficznerozliczeniekredytu.UseVisualStyleBackColor = true;
            this.obbtnGraficznerozliczeniekredytu.Click += new System.EventHandler(this.btnGraficznerozliczeniekredytu_Click);
            // 
            // obbtnResetujkredytu
            // 
            this.obbtnResetujkredytu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnResetujkredytu.Location = new System.Drawing.Point(307, 359);
            this.obbtnResetujkredytu.Name = "obbtnResetujkredytu";
            this.obbtnResetujkredytu.Size = new System.Drawing.Size(206, 57);
            this.obbtnResetujkredytu.TabIndex = 10;
            this.obbtnResetujkredytu.Text = "Resetuj";
            this.obbtnResetujkredytu.UseVisualStyleBackColor = true;
            this.obbtnResetujkredytu.Click += new System.EventHandler(this.btnResetujkredytu_Click);
            // 
            // obbtnTabelarycznerozliczeniekredytu
            // 
            this.obbtnTabelarycznerozliczeniekredytu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnTabelarycznerozliczeniekredytu.Location = new System.Drawing.Point(48, 359);
            this.obbtnTabelarycznerozliczeniekredytu.Name = "obbtnTabelarycznerozliczeniekredytu";
            this.obbtnTabelarycznerozliczeniekredytu.Size = new System.Drawing.Size(219, 57);
            this.obbtnTabelarycznerozliczeniekredytu.TabIndex = 9;
            this.obbtnTabelarycznerozliczeniekredytu.Text = "Tabelaryczne rozliczenie\r\nspłąty kredytu";
            this.obbtnTabelarycznerozliczeniekredytu.UseVisualStyleBackColor = true;
            this.obbtnTabelarycznerozliczeniekredytu.Click += new System.EventHandler(this.btnTabelarycznerozliczeniekredytu_Click);
            // 
            // obgpSpłatakredytuwlatach
            // 
            this.obgpSpłatakredytuwlatach.Controls.Add(this.obrdbRośne);
            this.obgpSpłatakredytuwlatach.Controls.Add(this.obrdbMaleące);
            this.obgpSpłatakredytuwlatach.Controls.Add(this.obrdbStała);
            this.obgpSpłatakredytuwlatach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obgpSpłatakredytuwlatach.Location = new System.Drawing.Point(12, 274);
            this.obgpSpłatakredytuwlatach.Name = "obgpSpłatakredytuwlatach";
            this.obgpSpłatakredytuwlatach.Size = new System.Drawing.Size(697, 64);
            this.obgpSpłatakredytuwlatach.TabIndex = 8;
            this.obgpSpłatakredytuwlatach.TabStop = false;
            this.obgpSpłatakredytuwlatach.Text = "Spłata kredytu w latach:";
            // 
            // obrdbRośne
            // 
            this.obrdbRośne.AutoSize = true;
            this.obrdbRośne.Location = new System.Drawing.Point(285, 22);
            this.obrdbRośne.Name = "obrdbRośne";
            this.obrdbRośne.Size = new System.Drawing.Size(107, 24);
            this.obrdbRośne.TabIndex = 2;
            this.obrdbRośne.Text = "rosnących";
            this.obrdbRośne.UseVisualStyleBackColor = true;
            // 
            // obrdbMaleące
            // 
            this.obrdbMaleące.AutoSize = true;
            this.obrdbMaleące.Checked = true;
            this.obrdbMaleące.Location = new System.Drawing.Point(145, 22);
            this.obrdbMaleące.Name = "obrdbMaleące";
            this.obrdbMaleące.Size = new System.Drawing.Size(110, 24);
            this.obrdbMaleące.TabIndex = 1;
            this.obrdbMaleące.TabStop = true;
            this.obrdbMaleące.Text = "maleących";
            this.obrdbMaleące.UseVisualStyleBackColor = true;
            // 
            // obrdbStała
            // 
            this.obrdbStała.AutoSize = true;
            this.obrdbStała.Location = new System.Drawing.Point(7, 22);
            this.obrdbStała.Name = "obrdbStała";
            this.obrdbStała.Size = new System.Drawing.Size(83, 24);
            this.obrdbStała.TabIndex = 0;
            this.obrdbStała.Text = "stałych";
            this.obrdbStała.UseVisualStyleBackColor = true;
            // 
            // obgpLiczbaRatWRokumKredytu
            // 
            this.obgpLiczbaRatWRokumKredytu.Controls.Add(this.obrdbComiesiąc);
            this.obgpLiczbaRatWRokumKredytu.Controls.Add(this.obrdbCokwartal);
            this.obgpLiczbaRatWRokumKredytu.Controls.Add(this.obrdbCopółroku);
            this.obgpLiczbaRatWRokumKredytu.Controls.Add(this.obrdbRazWRoku);
            this.obgpLiczbaRatWRokumKredytu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obgpLiczbaRatWRokumKredytu.Location = new System.Drawing.Point(12, 159);
            this.obgpLiczbaRatWRokumKredytu.Name = "obgpLiczbaRatWRokumKredytu";
            this.obgpLiczbaRatWRokumKredytu.Size = new System.Drawing.Size(697, 70);
            this.obgpLiczbaRatWRokumKredytu.TabIndex = 7;
            this.obgpLiczbaRatWRokumKredytu.TabStop = false;
            this.obgpLiczbaRatWRokumKredytu.Text = "Liczba rat w roku m:";
            // 
            // obrdbComiesiąc
            // 
            this.obrdbComiesiąc.AutoSize = true;
            this.obrdbComiesiąc.Location = new System.Drawing.Point(444, 34);
            this.obrdbComiesiąc.Name = "obrdbComiesiąc";
            this.obrdbComiesiąc.Size = new System.Drawing.Size(114, 24);
            this.obrdbComiesiąc.TabIndex = 3;
            this.obrdbComiesiąc.Text = "Co miesiąc";
            this.obrdbComiesiąc.UseVisualStyleBackColor = true;
            // 
            // obrdbCokwartal
            // 
            this.obrdbCokwartal.AutoSize = true;
            this.obrdbCokwartal.Checked = true;
            this.obrdbCokwartal.Location = new System.Drawing.Point(295, 34);
            this.obrdbCokwartal.Name = "obrdbCokwartal";
            this.obrdbCokwartal.Size = new System.Drawing.Size(109, 24);
            this.obrdbCokwartal.TabIndex = 2;
            this.obrdbCokwartal.TabStop = true;
            this.obrdbCokwartal.Text = "Co kwartał";
            this.obrdbCokwartal.UseVisualStyleBackColor = true;
            // 
            // obrdbCopółroku
            // 
            this.obrdbCopółroku.AutoSize = true;
            this.obrdbCopółroku.Location = new System.Drawing.Point(145, 34);
            this.obrdbCopółroku.Name = "obrdbCopółroku";
            this.obrdbCopółroku.Size = new System.Drawing.Size(115, 24);
            this.obrdbCopółroku.TabIndex = 1;
            this.obrdbCopółroku.Text = "Co pół roku";
            this.obrdbCopółroku.UseVisualStyleBackColor = true;
            // 
            // obrdbRazWRoku
            // 
            this.obrdbRazWRoku.AutoSize = true;
            this.obrdbRazWRoku.Location = new System.Drawing.Point(7, 34);
            this.obrdbRazWRoku.Name = "obrdbRazWRoku";
            this.obrdbRazWRoku.Size = new System.Drawing.Size(114, 24);
            this.obrdbRazWRoku.TabIndex = 0;
            this.obrdbRazWRoku.Text = "Raz w roku";
            this.obrdbRazWRoku.UseVisualStyleBackColor = true;
            // 
            // oblblRocznaStopaProcentowaKredytu
            // 
            this.oblblRocznaStopaProcentowaKredytu.AutoSize = true;
            this.oblblRocznaStopaProcentowaKredytu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblRocznaStopaProcentowaKredytu.Location = new System.Drawing.Point(386, 69);
            this.oblblRocznaStopaProcentowaKredytu.Name = "oblblRocznaStopaProcentowaKredytu";
            this.oblblRocznaStopaProcentowaKredytu.Size = new System.Drawing.Size(222, 40);
            this.oblblRocznaStopaProcentowaKredytu.TabIndex = 6;
            this.oblblRocznaStopaProcentowaKredytu.Text = "Roczna stopa procentowa p:\r\n(wybierz stopę procentową!)";
            // 
            // obtxtnKredytu
            // 
            this.obtxtnKredytu.Location = new System.Drawing.Point(263, 107);
            this.obtxtnKredytu.Name = "obtxtnKredytu";
            this.obtxtnKredytu.Size = new System.Drawing.Size(100, 22);
            this.obtxtnKredytu.TabIndex = 3;
            this.obtxtnKredytu.Text = "5";
            this.obtxtnKredytu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // obtxtKredytuK
            // 
            this.obtxtKredytuK.Location = new System.Drawing.Point(263, 69);
            this.obtxtKredytuK.Name = "obtxtKredytuK";
            this.obtxtKredytuK.Size = new System.Drawing.Size(100, 22);
            this.obtxtKredytuK.TabIndex = 2;
            this.obtxtKredytuK.Text = "5000";
            this.obtxtKredytuK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // oblblnKredytu
            // 
            this.oblblnKredytu.AutoSize = true;
            this.oblblnKredytu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblnKredytu.Location = new System.Drawing.Point(29, 109);
            this.oblblnKredytu.Name = "oblblnKredytu";
            this.oblblnKredytu.Size = new System.Drawing.Size(209, 20);
            this.oblblnKredytu.TabIndex = 1;
            this.oblblnKredytu.Text = "Liczba lat spłaty kredytu n:";
            // 
            // oblblKkredytu
            // 
            this.oblblKkredytu.AutoSize = true;
            this.oblblKkredytu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblKkredytu.Location = new System.Drawing.Point(72, 71);
            this.oblblKkredytu.Name = "oblblKkredytu";
            this.oblblKkredytu.Size = new System.Drawing.Size(166, 20);
            this.oblblKkredytu.TabIndex = 0;
            this.oblblKkredytu.Text = "Wysokość kredytu K:";
            // 
            // obbtnPowrótdoLokat
            // 
            this.obbtnPowrótdoLokat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnPowrótdoLokat.Location = new System.Drawing.Point(1124, 59);
            this.obbtnPowrótdoLokat.Name = "obbtnPowrótdoLokat";
            this.obbtnPowrótdoLokat.Size = new System.Drawing.Size(183, 130);
            this.obbtnPowrótdoLokat.TabIndex = 4;
            this.obbtnPowrótdoLokat.Text = "Przejście do formularza Lokaty";
            this.obbtnPowrótdoLokat.UseVisualStyleBackColor = true;
            this.obbtnPowrótdoLokat.Click += new System.EventHandler(this.btnPowrótdoLokat_Click);
            // 
            // obmenuStrip1
            // 
            this.obmenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.obmenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obfileToolStripMenuItem});
            this.obmenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.obmenuStrip1.Name = "obmenuStrip1";
            this.obmenuStrip1.Size = new System.Drawing.Size(1319, 30);
            this.obmenuStrip1.TabIndex = 5;
            this.obmenuStrip1.Text = "menuStrip1";
            // 
            // obfileToolStripMenuItem
            // 
            this.obfileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obwyjścieToolStripMenuItem,
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem,
            this.obpowrótDoFormularzaLokatyToolStripMenuItem});
            this.obfileToolStripMenuItem.Name = "obfileToolStripMenuItem";
            this.obfileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.obfileToolStripMenuItem.Text = "File";
            // 
            // obwyjścieToolStripMenuItem
            // 
            this.obwyjścieToolStripMenuItem.Name = "obwyjścieToolStripMenuItem";
            this.obwyjścieToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.obwyjścieToolStripMenuItem.Text = "Wyjście";
            this.obwyjścieToolStripMenuItem.Click += new System.EventHandler(this.wyjścieToolStripMenuItem_Click);
            // 
            // obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem
            // 
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem.Name = "obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem";
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem.Text = "Powrót do formularza kokpitu kalkulacji finansowych";
            this.obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem.Click += new System.EventHandler(this.powrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem_Click);
            // 
            // obpowrótDoFormularzaLokatyToolStripMenuItem
            // 
            this.obpowrótDoFormularzaLokatyToolStripMenuItem.Name = "obpowrótDoFormularzaLokatyToolStripMenuItem";
            this.obpowrótDoFormularzaLokatyToolStripMenuItem.Size = new System.Drawing.Size(439, 26);
            this.obpowrótDoFormularzaLokatyToolStripMenuItem.Text = "Powrót do formularza Lokaty";
            this.obpowrótDoFormularzaLokatyToolStripMenuItem.Click += new System.EventHandler(this.powrótDoFormularzaLokatyToolStripMenuItem_Click);
            // 
            // obtbkredytu
            // 
            this.obtbkredytu.AccessibleName = "";
            this.obtbkredytu.Controls.Add(this.obtbPulpitrozliczeniakredytu);
            this.obtbkredytu.Controls.Add(this.tbTabelarycznerozliczeniekredytu);
            this.obtbkredytu.Controls.Add(this.tbGraficznerozliczeniekredytu);
            this.obtbkredytu.Location = new System.Drawing.Point(25, 31);
            this.obtbkredytu.Name = "obtbkredytu";
            this.obtbkredytu.SelectedIndex = 0;
            this.obtbkredytu.Size = new System.Drawing.Size(1090, 656);
            this.obtbkredytu.TabIndex = 6;
            // 
            // obtbPulpitrozliczeniakredytu
            // 
            this.obtbPulpitrozliczeniakredytu.Controls.Add(this.obpanel1);
            this.obtbPulpitrozliczeniakredytu.Location = new System.Drawing.Point(4, 25);
            this.obtbPulpitrozliczeniakredytu.Name = "obtbPulpitrozliczeniakredytu";
            this.obtbPulpitrozliczeniakredytu.Padding = new System.Windows.Forms.Padding(3);
            this.obtbPulpitrozliczeniakredytu.Size = new System.Drawing.Size(1274, 627);
            this.obtbPulpitrozliczeniakredytu.TabIndex = 0;
            this.obtbPulpitrozliczeniakredytu.Text = "Pulpit rozliczenia kredytu";
            this.obtbPulpitrozliczeniakredytu.UseVisualStyleBackColor = true;
            // 
            // tbTabelarycznerozliczeniekredytu
            // 
            this.tbTabelarycznerozliczeniekredytu.Controls.Add(this.obpanel2);
            this.tbTabelarycznerozliczeniekredytu.Location = new System.Drawing.Point(4, 25);
            this.tbTabelarycznerozliczeniekredytu.Name = "tbTabelarycznerozliczeniekredytu";
            this.tbTabelarycznerozliczeniekredytu.Padding = new System.Windows.Forms.Padding(3);
            this.tbTabelarycznerozliczeniekredytu.Size = new System.Drawing.Size(1082, 627);
            this.tbTabelarycznerozliczeniekredytu.TabIndex = 1;
            this.tbTabelarycznerozliczeniekredytu.Text = "Tabelaryczne rozliczenie kredytu";
            this.tbTabelarycznerozliczeniekredytu.UseVisualStyleBackColor = true;
            // 
            // obpanel2
            // 
            this.obpanel2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.obpanel2.Controls.Add(this.obdgvRozliczenieRatyKredytu);
            this.obpanel2.Controls.Add(this.obtxtRk);
            this.obpanel2.Controls.Add(this.oblabel1);
            this.obpanel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.obpanel2.Location = new System.Drawing.Point(-4, 3);
            this.obpanel2.Name = "obpanel2";
            this.obpanel2.Size = new System.Drawing.Size(1016, 449);
            this.obpanel2.TabIndex = 0;
            // 
            // obdgvRozliczenieRatyKredytu
            // 
            this.obdgvRozliczenieRatyKredytu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.obdgvRozliczenieRatyKredytu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Numerraty,
            this.Stanzadłużeniaprzedpłaceniemjtejraty,
            this.WysokośćratyodsetkowejRo,
            this.WysokośćratykapitalowejRk,
            this.Stanzadłużeniapowpłaceniujtejraty});
            this.obdgvRozliczenieRatyKredytu.Location = new System.Drawing.Point(40, 71);
            this.obdgvRozliczenieRatyKredytu.Name = "obdgvRozliczenieRatyKredytu";
            this.obdgvRozliczenieRatyKredytu.RowHeadersWidth = 51;
            this.obdgvRozliczenieRatyKredytu.RowTemplate.Height = 24;
            this.obdgvRozliczenieRatyKredytu.Size = new System.Drawing.Size(911, 375);
            this.obdgvRozliczenieRatyKredytu.TabIndex = 2;
            // 
            // Numerraty
            // 
            this.Numerraty.HeaderText = "Numer raty";
            this.Numerraty.MinimumWidth = 6;
            this.Numerraty.Name = "Numerraty";
            this.Numerraty.Width = 125;
            // 
            // Stanzadłużeniaprzedpłaceniemjtejraty
            // 
            this.Stanzadłużeniaprzedpłaceniemjtejraty.HeaderText = "Stan zadłużenia przed płaceniem j-tej raty";
            this.Stanzadłużeniaprzedpłaceniemjtejraty.MinimumWidth = 6;
            this.Stanzadłużeniaprzedpłaceniemjtejraty.Name = "Stanzadłużeniaprzedpłaceniemjtejraty";
            this.Stanzadłużeniaprzedpłaceniemjtejraty.Width = 125;
            // 
            // WysokośćratyodsetkowejRo
            // 
            this.WysokośćratyodsetkowejRo.HeaderText = "Wysokość raty odsetkowej Ro";
            this.WysokośćratyodsetkowejRo.MinimumWidth = 6;
            this.WysokośćratyodsetkowejRo.Name = "WysokośćratyodsetkowejRo";
            this.WysokośćratyodsetkowejRo.Width = 125;
            // 
            // WysokośćratykapitalowejRk
            // 
            this.WysokośćratykapitalowejRk.HeaderText = "Wysokość raty kapitalowej Rk";
            this.WysokośćratykapitalowejRk.MinimumWidth = 6;
            this.WysokośćratykapitalowejRk.Name = "WysokośćratykapitalowejRk";
            this.WysokośćratykapitalowejRk.Width = 125;
            // 
            // Stanzadłużeniapowpłaceniujtejraty
            // 
            this.Stanzadłużeniapowpłaceniujtejraty.HeaderText = "Stan zadłużenia po wpłaceniu j-tej raty";
            this.Stanzadłużeniapowpłaceniujtejraty.MinimumWidth = 6;
            this.Stanzadłużeniapowpłaceniujtejraty.Name = "Stanzadłużeniapowpłaceniujtejraty";
            this.Stanzadłużeniapowpłaceniujtejraty.Width = 125;
            // 
            // obtxtRk
            // 
            this.obtxtRk.Location = new System.Drawing.Point(627, 28);
            this.obtxtRk.Name = "obtxtRk";
            this.obtxtRk.ReadOnly = true;
            this.obtxtRk.Size = new System.Drawing.Size(197, 22);
            this.obtxtRk.TabIndex = 1;
            // 
            // oblabel1
            // 
            this.oblabel1.AutoSize = true;
            this.oblabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblabel1.Location = new System.Drawing.Point(63, 27);
            this.oblabel1.Name = "oblabel1";
            this.oblabel1.Size = new System.Drawing.Size(518, 23);
            this.oblabel1.TabIndex = 0;
            this.oblabel1.Text = "Wysokość  raty kapitalowej Rk (która jest stała, czyli const)";
            // 
            // tbGraficznerozliczeniekredytu
            // 
            this.tbGraficznerozliczeniekredytu.Controls.Add(this.obpanel3);
            this.tbGraficznerozliczeniekredytu.Location = new System.Drawing.Point(4, 25);
            this.tbGraficznerozliczeniekredytu.Name = "tbGraficznerozliczeniekredytu";
            this.tbGraficznerozliczeniekredytu.Size = new System.Drawing.Size(1082, 627);
            this.tbGraficznerozliczeniekredytu.TabIndex = 2;
            this.tbGraficznerozliczeniekredytu.Text = "Graficzne rozliczenie kredytu";
            this.tbGraficznerozliczeniekredytu.UseVisualStyleBackColor = true;
            // 
            // obpanel3
            // 
            this.obpanel3.BackColor = System.Drawing.Color.Orchid;
            this.obpanel3.Controls.Add(this.oblblGrafikMalejący);
            this.obpanel3.Controls.Add(this.oblblGrafikRosnący);
            this.obpanel3.Controls.Add(this.oblblGrafikStały);
            this.obpanel3.Controls.Add(this.splitter1);
            this.obpanel3.Controls.Add(this.obchtWykres);
            this.obpanel3.Location = new System.Drawing.Point(3, 3);
            this.obpanel3.Name = "obpanel3";
            this.obpanel3.Size = new System.Drawing.Size(1079, 621);
            this.obpanel3.TabIndex = 0;
            // 
            // oblblGrafikMalejący
            // 
            this.oblblGrafikMalejący.AutoSize = true;
            this.oblblGrafikMalejący.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblGrafikMalejący.Location = new System.Drawing.Point(265, 13);
            this.oblblGrafikMalejący.Name = "oblblGrafikMalejący";
            this.oblblGrafikMalejący.Size = new System.Drawing.Size(408, 20);
            this.oblblGrafikMalejący.TabIndex = 4;
            this.oblblGrafikMalejący.Text = "Rozliczenie spłaty kredytu w ratach malejących";
            this.oblblGrafikMalejący.Visible = false;
            // 
            // oblblGrafikRosnący
            // 
            this.oblblGrafikRosnący.AutoSize = true;
            this.oblblGrafikRosnący.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblGrafikRosnący.Location = new System.Drawing.Point(265, 13);
            this.oblblGrafikRosnący.Name = "oblblGrafikRosnący";
            this.oblblGrafikRosnący.Size = new System.Drawing.Size(400, 20);
            this.oblblGrafikRosnący.TabIndex = 3;
            this.oblblGrafikRosnący.Text = "Rozliczenie spłaty kredytu w ratach rosnących";
            this.oblblGrafikRosnący.Visible = false;
            // 
            // oblblGrafikStały
            // 
            this.oblblGrafikStały.AutoSize = true;
            this.oblblGrafikStały.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblGrafikStały.Location = new System.Drawing.Point(265, 13);
            this.oblblGrafikStały.Name = "oblblGrafikStały";
            this.oblblGrafikStały.Size = new System.Drawing.Size(374, 20);
            this.oblblGrafikStały.TabIndex = 2;
            this.oblblGrafikStały.Text = "Rozliczenie spłaty kredytu w ratach stałych";
            this.oblblGrafikStały.Visible = false;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 621);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // obchtWykres
            // 
            this.obchtWykres.BackColor = System.Drawing.Color.Orchid;
            chartArea5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            chartArea5.Name = "ChartArea1";
            this.obchtWykres.ChartAreas.Add(chartArea5);
            legend5.BackColor = System.Drawing.Color.White;
            legend5.Name = "Legend1";
            this.obchtWykres.Legends.Add(legend5);
            this.obchtWykres.Location = new System.Drawing.Point(0, 36);
            this.obchtWykres.Name = "obchtWykres";
            series13.ChartArea = "ChartArea1";
            series13.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series13.Legend = "Legend1";
            series13.Name = "Rata odsetkowa Ro";
            series14.ChartArea = "ChartArea1";
            series14.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series14.Legend = "Legend1";
            series14.Name = "Rata kapitalowa Rk";
            series15.ChartArea = "ChartArea1";
            series15.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series15.Legend = "Legend1";
            series15.Name = "Rata lączna R=Ro + Rk";
            this.obchtWykres.Series.Add(series13);
            this.obchtWykres.Series.Add(series14);
            this.obchtWykres.Series.Add(series15);
            this.obchtWykres.Size = new System.Drawing.Size(1036, 541);
            this.obchtWykres.TabIndex = 0;
            this.obchtWykres.Text = "chart1";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // obKredyty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1319, 699);
            this.Controls.Add(this.obtbkredytu);
            this.Controls.Add(this.obbtnPowrótdoLokat);
            this.Controls.Add(this.obmenuStrip1);
            this.MainMenuStrip = this.obmenuStrip1;
            this.Name = "obKredyty";
            this.Text = "Kredyty";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Kredyty_FormClosing);
            this.obpanel1.ResumeLayout(false);
            this.obpanel1.PerformLayout();
            this.obgpSpłatakredytuwlatach.ResumeLayout(false);
            this.obgpSpłatakredytuwlatach.PerformLayout();
            this.obgpLiczbaRatWRokumKredytu.ResumeLayout(false);
            this.obgpLiczbaRatWRokumKredytu.PerformLayout();
            this.obmenuStrip1.ResumeLayout(false);
            this.obmenuStrip1.PerformLayout();
            this.obtbkredytu.ResumeLayout(false);
            this.obtbPulpitrozliczeniakredytu.ResumeLayout(false);
            this.tbTabelarycznerozliczeniekredytu.ResumeLayout(false);
            this.obpanel2.ResumeLayout(false);
            this.obpanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvRozliczenieRatyKredytu)).EndInit();
            this.tbGraficznerozliczeniekredytu.ResumeLayout(false);
            this.obpanel3.ResumeLayout(false);
            this.obpanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obchtWykres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel obpanel1;
        private System.Windows.Forms.Label oblblnKredytu;
        private System.Windows.Forms.Label oblblKkredytu;
        private System.Windows.Forms.Button obbtnPowrótdoLokat;
        private System.Windows.Forms.Label oblblRocznaStopaProcentowaKredytu;
        private System.Windows.Forms.TextBox obtxtnKredytu;
        private System.Windows.Forms.TextBox obtxtKredytuK;
        private System.Windows.Forms.MenuStrip obmenuStrip1;
        private System.Windows.Forms.Button obbtnGraficznerozliczeniekredytu;
        private System.Windows.Forms.Button obbtnResetujkredytu;
        private System.Windows.Forms.Button obbtnTabelarycznerozliczeniekredytu;
        private System.Windows.Forms.GroupBox obgpSpłatakredytuwlatach;
        private System.Windows.Forms.RadioButton obrdbRośne;
        private System.Windows.Forms.RadioButton obrdbMaleące;
        private System.Windows.Forms.RadioButton obrdbStała;
        private System.Windows.Forms.GroupBox obgpLiczbaRatWRokumKredytu;
        private System.Windows.Forms.RadioButton obrdbComiesiąc;
        private System.Windows.Forms.RadioButton obrdbCokwartal;
        private System.Windows.Forms.RadioButton obrdbCopółroku;
        private System.Windows.Forms.RadioButton obrdbRazWRoku;
        private System.Windows.Forms.TabControl obtbkredytu;
        private System.Windows.Forms.TabPage obtbPulpitrozliczeniakredytu;
        private System.Windows.Forms.TabPage tbTabelarycznerozliczeniekredytu;
        private System.Windows.Forms.TabPage tbGraficznerozliczeniekredytu;
        private System.Windows.Forms.Panel obpanel2;
        private System.Windows.Forms.DataGridView obdgvRozliczenieRatyKredytu;
        private System.Windows.Forms.TextBox obtxtRk;
        private System.Windows.Forms.Label oblabel1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel obpanel3;
        private System.Windows.Forms.DataVisualization.Charting.Chart obchtWykres;
        private System.Windows.Forms.ListBox oblbRocznaStopaProcentowaKredytu;
        private System.Windows.Forms.ToolStripMenuItem obfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obwyjścieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obpowrótDoFormularzaKokpituKalkulacjiFinansowychToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obpowrótDoFormularzaLokatyToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numerraty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stanzadłużeniaprzedpłaceniemjtejraty;
        private System.Windows.Forms.DataGridViewTextBoxColumn WysokośćratyodsetkowejRo;
        private System.Windows.Forms.DataGridViewTextBoxColumn WysokośćratykapitalowejRk;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stanzadłużeniapowpłaceniujtejraty;
        private System.Windows.Forms.TextBox obtxtKnm;
        private System.Windows.Forms.Label oblblSumabankowarat;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label oblblGrafikMalejący;
        private System.Windows.Forms.Label oblblGrafikRosnący;
        private System.Windows.Forms.Label oblblGrafikStały;
    }
}