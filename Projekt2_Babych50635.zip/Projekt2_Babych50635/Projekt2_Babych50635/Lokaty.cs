﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Projekt2_Babych50635
{

    public partial class obLokaty : Form
    {
       
        public obLokaty()
        {
            InitializeComponent();

            //domyśle wybranie rocznej stopy procentowej
            obcmbRocznaStopaProcentowa.SelectedIndex= 0;
        }
        bool PobranieDanychWejsciowych(out float obK, out ushort obn, out float obp, out ushort obm)
        {// domyślne ustawienie wartości "Wyjścia"
            obK = 0.0F; obn = 0; obp = 0.0F; obm = 0;

            // pobieranie danych  
            // pobranie lokaty kapitalowej K
            if (string.IsNullOrEmpty(obtxtK.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtK, "ERROR: musisz podać wysokośc lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!float.TryParse(obtxtK.Text, out obK))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtK, "ERROR: wystąpił niedozwolony znak w zapisie wysokości lokaty K!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obK >= 100
            if (obK < 100.0F)
            {
                errorProvider1.SetError(obtxtK, "ERROR: wysokości lokaty K musi spełniać warunek wejściowy: K >= 100!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie liczby lat lokaty obn

            // pobieranie danych  
            // pobranie lat lokaty obn
            if (string.IsNullOrEmpty(obtxtn.Text))
            {// nie wpisano zadnej danej, to sygnalizujemy blad
                errorProvider1.SetError(obtxtn, "ERROR: musisz podać lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            if (!ushort.TryParse(obtxtn.Text, out obn))
            {// był błąd, to go sygnalizujemy
                errorProvider1.SetError(obtxtn, "ERROR: wystąpił niedozwolony znak w zapisie lizby lat lokaty n!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // sprawdzenie warunku wejściowego: obn >= 1
            if (obn <= 0)
            {
                errorProvider1.SetError(obtxtn, "ERROR:liczba lat lokaty n musi spełniać warunek wejściowy: n > 0!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // pobranie znakowego zapisu stopy procentowej (bez znaku %)




            // pobranie rocznej stopy procentowej
            // czy użytkownik wybrał jakąś stopy procentowej

            if (obcmbRocznaStopaProcentowa.SelectedIndex < 0.000) // == -1
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: musisz wybrać roczna stopę procentową!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
            string obRocznaStopa = obcmbRocznaStopaProcentowa.SelectedItem.ToString();
            obRocznaStopa = obRocznaStopa.Trim();

            obRocznaStopa = obRocznaStopa.Substring(0, obRocznaStopa.Length - 1);

            // konwersja na wartość
            if (!float.TryParse(obRocznaStopa, out obp))
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: wystąpił niedozwolony znak w zapisie rocznej stopy procentowej!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider
                                          // przeliczenia mianowej stopy procentowej na wartość rzeczywistą

            obp = obp / 100;
            // sprawdzenie warunku wejściowego
            if (obp <= 0.00F || obp >= 1.0F)
            {
                errorProvider1.SetError(obcmbRocznaStopaProcentowa, "ERROR: roczna stopa procentowa musi spełniać warunek wejściowy: 0% < p < 100%!");
                return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd
            }
            else
                errorProvider1.Dispose(); // "zgaszenie" errorProvider

            // pobranie częstości kapitalizacki odsetek m
            if (obrdbCoRoku.Checked)
                obm = 1;
            else
           if (obrdbCoPółRoku.Checked)
                obm = 2;
            else
            if (obrdbCoKwartal.Checked)
                obm = 4;
            else
            if (obrdbCoMiesiąc.Checked)
                obm = 12;
            else
            { 
                obm = 1; // domyślnie
            errorProvider1.SetError(obgpCzętośćKapitalizacjiOdsetek, "ERROR: musisz wybrać częstość kapitalizacji odsetek!");
            return false; // przerywamy dalsze pobieranie danych i przekazujemy informacje, ze był błąd    

        }
            return true;

        }


     

        private void btnObliczKnm_Click(object sender, EventArgs obe)
        {
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK, obp, obKnm;
            ushort obn, obm;
            //pobranie danych wejściowych
            if (!PobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
            {
                return;
            }

            obKnm = obK * (float)Math.Pow(1 + obp / obm, obn * obm);
            //wizualizacja wyniku
            obtxtKnm.Visible = true;
            obtxtKnm.Text = obKnm.ToString();
         
            obtxtK.Enabled = false;
            obtxtn.Enabled = false;
            obcmbRocznaStopaProcentowa.Enabled = false;
            
            
                
            oblblKnm.Visible = true;
            obgpCzętośćKapitalizacjiOdsetek.Enabled = false;
            //ustawienie stanu braku aktywności dla obługiwanego przycisku
            obbtnObliczKnm.Enabled = false;

        }
     private void TabelaryczneRozliczenieLokaty(float obK, ushort obn, float obp, ushort obm, out float[,] obTrl)
        {
            obTrl = new float[obn * obm + 1, 3];
            obTrl[0, 0] = 0.0F;
            obTrl[0, 1] = 0.0F;
            obTrl[0, 2] = obK;
            for (ushort obi = 1; obi < obTrl.GetLength(0); obi++)
            {
                obTrl[obi, 0] = obTrl[obi - 1, 2];
                obTrl[obi, 1] = obTrl[obi, 0] * obp / obm;
                obTrl[obi, 2] = obTrl[obi, 0] + obTrl[obi, 1];

            }
        }

        private void btnRozliczLokateTabelaryczne_Click(object sender, EventArgs obe)
        {
            //deklaracje zminnych dla przechowania pobranych danych wejściowych
            float obK, obp;
            ushort obn, obm;
            //pobranie danych wejściowych
            if (!PobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
            {
                //dodatkowe zapalenie kontrolki errorProvider przy przycisku polecić Oblicz wartość przyśła Knm
                errorProvider2.SetError(obbtnObliczKnm, "ERROR: obsługa tego przycisku nie może być kontynuowana, gdy wystąpił błąd w dawych wejściowych");
                return;

            }
            //deklaracja referencyjnej zmiennej tablicowej
            float[,] obTrl;
            // wywolanie metody dla tabelarycznego rozliczenia lokaty
            TabelaryczneRozliczenieLokaty(obK, obn, obp, obm, out obTrl);

            
            //wpisanie do kontrolki DataGridView danych z tablicy TRL
            for (ushort i = 0; i < obTrl.GetLength(0); i++)
            {// dodanie do kontrolki DataGridView nowego wiersza
                obdgvTabeleryczneRozliczenieLokaty.Rows.Add();
                // wpisanie (przepisanie) danych z i-tego wiersza tablicy TLR do dodanego wiersza kontrolki DataGridView
                obdgvTabeleryczneRozliczenieLokaty.Rows[i].Cells[0].Value = i;
                obdgvTabeleryczneRozliczenieLokaty.Rows[i].Cells[1].Value = string.Format("{0:0.000}", obTrl[i, 0]); //stan na początku i-tego okresu
                obdgvTabeleryczneRozliczenieLokaty.Rows[i].Cells[2].Value = string.Format("{0:0.000}", obTrl[i, 1]); //ocetki za i-tty okres
                obdgvTabeleryczneRozliczenieLokaty.Rows[i].Cells[3].Value = string.Format("{0:0.000}", obTrl[i, 2]); //stan na końcu i-tego okresu
                if (i % 2 == 0)
                    obdgvTabeleryczneRozliczenieLokaty.Rows[i].DefaultCellStyle.BackColor = Color.LightGray;
                else
                    obdgvTabeleryczneRozliczenieLokaty.Rows[i].DefaultCellStyle.BackColor = Color.White;
            }
            obdgvTabeleryczneRozliczenieLokaty.RowTemplate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //odsłonięcie kontrolek tabelarycznej viwizualizacji rozliczenia lokaty
            oblblRozliczenieTabeleryczne.Visible = true;
            

            obtxtK.Enabled = false;
            obtxtn.Enabled = false;
            obcmbRocznaStopaProcentowa.Enabled = false;
            obgpCzętośćKapitalizacjiOdsetek.Enabled = false;
          

            oblblWykres.Visible= false;
            obchtWykres.Visible = false;
            obdgvTabeleryczneRozliczenieLokaty.Visible = true;
            //ustawienia stanu braku aktywności dla obsługiwanego przycisku
            
            obbtnRozliczLokateTabelaryczne.Enabled = false;

        }

        private void btnGraficznarozliczenialokaty_Click(object sender, EventArgs obe)
        {
            
                
                //deklaracje zminnych dla przechowania pobranych danych wejściowych
                float obK, obp;
                ushort obn, obm;
                //pobranie danych wejściowych
                if (!PobranieDanychWejsciowych(out obK, out obn, out obp, out obm))
                {
                    //dodatkowe zapalenie kontrolki errorProvider przy przycisku poleceć Oblić wartość przyśła Knn
                    errorProvider2.SetError(obbtnObliczKnm, "ERROR: obsługa tego przycisku nie może być kontynuowana, gdy wystąpił błąd w dawych wejściowych");
                    return;

                }
                //deklaracja referencyjnej zmiennej tablicowej
                float[,] Trl;
                // wywolanie metody dla tabelarycznego rozliczenia lokaty
                TabelaryczneRozliczenieLokaty(obK, obn, obp, obm, out Trl);
                // sformatowanie kontrolki Chart
                // zerowanie serii danych kontrolki Chart
                obchtWykres.Series.Clear();
                // dodanie nowej serii danych
                obchtWykres.Series.Add("Stan konta Knm");
                // opisanie osi układu współrzednych
                obchtWykres.ChartAreas[0].AxisX.Title = "Okresy lokaty";
                obchtWykres.ChartAreas[0].AxisY.Title = "Wysokość stanu konta Knm";
                // uwidocznienie legendy wykresu
                obchtWykres.Series[0].IsVisibleInLegend = true;
                obchtWykres.Legends.FindByName("Legend1").Docking = Docking.Bottom;
                // ustalenie nazwy wykresu
                obchtWykres.Series[0].Name = "Wykres zmiany stanu konta lokaty";
                obchtWykres.Series[0].ChartType = SeriesChartType.Line;
                obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.Dot;
                obchtWykres.Series[0].BorderWidth = 2;
                // wpisanie danych do serii danych wykresu o numerze 0
                for (ushort obi = 0; obi < Trl.GetLength(0); obi++)
                {
                    obchtWykres.Series[0].Points.AddXY(obi, Trl[obi, 2]);
                }
                // odsłonięcie kontrolek

                oblblRozliczenieTabeleryczne.Visible = false;
                obchtWykres.Visible = true;
                // lblWykres.Enabled = false;
                obdgvTabeleryczneRozliczenieLokaty.Visible = false;
                oblblWykres.Visible = true;
            
            obtxtK.Enabled = false;
            obtxtn.Enabled = false;
            obcmbRocznaStopaProcentowa.Enabled = false;
            obgpCzętośćKapitalizacjiOdsetek.Enabled = false;
            
            
            obbtnZmieńkolorliniiwykresu.Visible = true;
            obtbGrubośćlinii.Visible = true;
            oblblGrubośćlinii.Visible = true;
            obcmbGrubośćlinii.Visible = true;
            oblistbStylliniiwykresu.Visible = true;
            oblblStyllinii.Visible = true;

              //
                // ustawienie stanu braku aktywności przycisku
                obbtnGraficznarozliczenialokaty.Enabled = false;
            obbtnZmieńkolortła.Visible = true;
           
            }



            private void btnResetuj_Click(object sender, EventArgs obe)
        {


            oblblStyllinii.Visible = false;
            oblistbStylliniiwykresu.Visible = false;
            obbtnZmieńkolorliniiwykresu.Visible = false;
                obbtnZmieńkolortła.Visible = false;
                obcmbGrubośćlinii.Visible = false;
            oblblGrubośćlinii.Visible = false;

                obtbGrubośćlinii.Visible = false;
            obtxtK.Clear();

            obtxtK.Enabled = true;
            obtxtn.Text = "";
            obtxtn.Enabled = true;
            obcmbRocznaStopaProcentowa.SelectedIndex = 0;
            obcmbRocznaStopaProcentowa.Enabled = true;
            obgpCzętośćKapitalizacjiOdsetek.Enabled = true;
            obrdbCoKwartal.Checked = true;
            obtxtKnm.Visible = false;
            obtxtKnm.Clear();
            obdgvTabeleryczneRozliczenieLokaty.Rows.Clear();
            obchtWykres.Series.Clear();
            oblblKnm.Visible = false;
            oblblRozliczenieTabeleryczne.Visible = false;
            
            oblblWykres.Visible = false;
            obchtWykres.Visible = false;
            obbtnObliczKnm.Enabled = true;
            obbtnRozliczLokateTabelaryczne.Enabled = true;
            obbtnGraficznarozliczenialokaty.Enabled = true;

                



        }

        private void btnZmieńkolorliniiwykresu_Click(object sender, EventArgs obe)
        {
            ColorDialog obOknoKolorów = new ColorDialog();
            obOknoKolorów.Color = obchtWykres.Series[0].Color;
            if (obOknoKolorów.ShowDialog() == DialogResult.OK)

                obchtWykres.Series[0].Color = obOknoKolorów.Color;
            
        }

        private void btnZmieńkolortła_Click(object sender, EventArgs obe)
        {
            //otworzenie egzemplarza palety okna koloru
            ColorDialog obOknoKolorów = new ColorDialog();
            //zaznaczenie koloru tła w oknie kolorów
            obOknoKolorów.Color = obchtWykres.BackColor;
            //wyświetlenie okna kolorów i odczytanie decyzji urzytkowników
            if (obOknoKolorów.ShowDialog() == DialogResult.OK)
                //zmieniamy kolor tła wykresu
                obchtWykres.BackColor = obOknoKolorów.Color;

        }

        private void tbGrubośćlinii_Scroll(object sender, EventArgs obe)
        {
            //odczytanie ustawionej w TrackBar grubości linii i jej wpisanie do grubości linii wykresu
            obchtWykres.Series[0].BorderWidth = obtbGrubośćlinii.Value;

            obcmbGrubośćlinii.SelectedIndex = obtbGrubośćlinii.Value;
        }

        private void cmbGrubośćlinii_SelectedIndexChanged(object sender, EventArgs obe)
        {
            obchtWykres.Series[0].BorderWidth = int.Parse(obcmbGrubośćlinii.SelectedItem.ToString());
            obtbGrubośćlinii.Value = int.Parse(obcmbGrubośćlinii.SelectedItem.ToString());
            

        }

        private void listbStylliniiwykresu_SelectedIndexChanged(object sender, EventArgs obe)
        {

            switch (oblistbStylliniiwykresu.SelectedIndex)
            {

                case 0:
                    obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.Dash;
                    break;
                case 1:
                    obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDot;
                    break;
                case 2:
                    obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDotDot;
                    break;
                
               



            }

                }

        
        private void kolorLiniiWykresuToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            ColorDialog obOknoKolorów = new ColorDialog();
            obOknoKolorów.Color = obchtWykres.Series[0].Color;
            if (obOknoKolorów.ShowDialog() == DialogResult.OK)

                obchtWykres.Series[0].Color = obOknoKolorów.Color;
            
        }

        private void kolorTłaWykresuToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            //otworzenie egzemplarza palety okna koloru
            ColorDialog obOknoKolorów = new ColorDialog();
            //zaznaczenie koloru tła w oknie kolorów
            obOknoKolorów.Color = obchtWykres.BackColor;
            //wyświetlenie okna kolorów i odczytanie decyzji urzytkowników
            if (obOknoKolorów.ShowDialog() == DialogResult.OK)
                //zmieniamy kolor tła wykresu
                obchtWykres.BackColor = obOknoKolorów.Color;
        }

        private void wyjścieToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            
            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();
                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                     "zdarzenia było:" +  ")");


                    break;
                
            }

        }

        private void kreskowaToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.Dash;

        }

        private void kreskowoKropkowaDashDotToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDot;
        }

        private void kreskowoKropkowakropkowaDashDotDotToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            obchtWykres.Series[0].BorderDashStyle = ChartDashStyle.DashDotDot;
        }

        private void btnPowrótdokokpitu_Click(object sender, EventArgs obe)
        {
            obKokpitprojektukalkulacjifinansowych obq = new obKokpitprojektukalkulacjifinansowych();
            obq.Show();
            Hide();


        }

        private void powrótDoFormularzaKredytówToolStripMenuItem_Click(object sender, EventArgs obe)
        {
            obKredyty obl = new obKredyty();
            obl.Show();
            Hide();
        }

        private void Lokaty_FormClosing(object sender, FormClosingEventArgs obe)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji = 
                MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz", 
                this.Text,
                MessageBoxButtons.YesNoCancel, 
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();
                    
                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason+  ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }
                    
            
        }

        
    }
}

