﻿namespace Projekt2_Babych50635
{
    partial class obKokpitprojektukalkulacjifinansowych
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oblblKalkulacjefinansowe = new System.Windows.Forms.Label();
            this.obbtnRozliczanielokatkapitalowych = new System.Windows.Forms.Button();
            this.obbtnRozliczaniekredytów = new System.Windows.Forms.Button();
            this.obKalkulacjadodatkowa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // oblblKalkulacjefinansowe
            // 
            this.oblblKalkulacjefinansowe.AutoSize = true;
            this.oblblKalkulacjefinansowe.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblblKalkulacjefinansowe.Location = new System.Drawing.Point(489, 58);
            this.oblblKalkulacjefinansowe.Name = "oblblKalkulacjefinansowe";
            this.oblblKalkulacjefinansowe.Size = new System.Drawing.Size(369, 43);
            this.oblblKalkulacjefinansowe.TabIndex = 0;
            this.oblblKalkulacjefinansowe.Text = "Kalkulacje finansowe\r\n";
            this.oblblKalkulacjefinansowe.Click += new System.EventHandler(this.oblblKalkulacjefinansowe_Click);
            // 
            // obbtnRozliczanielokatkapitalowych
            // 
            this.obbtnRozliczanielokatkapitalowych.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnRozliczanielokatkapitalowych.Location = new System.Drawing.Point(188, 174);
            this.obbtnRozliczanielokatkapitalowych.Name = "obbtnRozliczanielokatkapitalowych";
            this.obbtnRozliczanielokatkapitalowych.Size = new System.Drawing.Size(298, 103);
            this.obbtnRozliczanielokatkapitalowych.TabIndex = 1;
            this.obbtnRozliczanielokatkapitalowych.Text = "Rozliczanie lokat kapitalowych";
            this.obbtnRozliczanielokatkapitalowych.UseVisualStyleBackColor = true;
            this.obbtnRozliczanielokatkapitalowych.Click += new System.EventHandler(this.btnRozliczanielokatkapitalowych_Click);
            // 
            // obbtnRozliczaniekredytów
            // 
            this.obbtnRozliczaniekredytów.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnRozliczaniekredytów.Location = new System.Drawing.Point(867, 174);
            this.obbtnRozliczaniekredytów.Name = "obbtnRozliczaniekredytów";
            this.obbtnRozliczaniekredytów.Size = new System.Drawing.Size(337, 103);
            this.obbtnRozliczaniekredytów.TabIndex = 2;
            this.obbtnRozliczaniekredytów.Text = "Rozliczanie kredytów";
            this.obbtnRozliczaniekredytów.UseVisualStyleBackColor = true;
            this.obbtnRozliczaniekredytów.Click += new System.EventHandler(this.btnRozliczaniekredytów_Click);
            // 
            // obKalkulacjadodatkowa
            // 
            this.obKalkulacjadodatkowa.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obKalkulacjadodatkowa.Location = new System.Drawing.Point(531, 174);
            this.obKalkulacjadodatkowa.Name = "obKalkulacjadodatkowa";
            this.obKalkulacjadodatkowa.Size = new System.Drawing.Size(296, 103);
            this.obKalkulacjadodatkowa.TabIndex = 3;
            this.obKalkulacjadodatkowa.Text = "Kalkulacja dodatkowa";
            this.obKalkulacjadodatkowa.UseVisualStyleBackColor = true;
            this.obKalkulacjadodatkowa.Click += new System.EventHandler(this.obKalkulacjadodatkowa_Click);
            // 
            // obKokpitprojektukalkulacjifinansowych
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1428, 713);
            this.Controls.Add(this.obKalkulacjadodatkowa);
            this.Controls.Add(this.obbtnRozliczaniekredytów);
            this.Controls.Add(this.obbtnRozliczanielokatkapitalowych);
            this.Controls.Add(this.oblblKalkulacjefinansowe);
            this.Name = "obKokpitprojektukalkulacjifinansowych";
            this.Text = "Kokpit projektu kalkulacji finansowych";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Kokpitprojektukalkulacjifinansowych_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label oblblKalkulacjefinansowe;
        private System.Windows.Forms.Button obbtnRozliczanielokatkapitalowych;
        private System.Windows.Forms.Button obbtnRozliczaniekredytów;
        private System.Windows.Forms.Button obKalkulacjadodatkowa;
    }
}