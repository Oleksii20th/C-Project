﻿namespace ProjektNr1_Babych50635
{
    partial class WykresZmianWartościSzeregupotęgowego
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WykresZmianWartościSzeregupotęgowego));
            this.obtxth = new System.Windows.Forms.TextBox();
            this.obtxtXg = new System.Windows.Forms.TextBox();
            this.obtxtXd = new System.Windows.Forms.TextBox();
            this.obtxtEps = new System.Windows.Forms.TextBox();
            this.oblbh = new System.Windows.Forms.Label();
            this.oblbXg = new System.Windows.Forms.Label();
            this.oblbXd = new System.Windows.Forms.Label();
            this.oblbEps = new System.Windows.Forms.Label();
            this.obMenu = new System.Windows.Forms.MenuStrip();
            this.Menustrip = new System.Windows.Forms.ToolStripMenuItem();
            this.obZapiszTablicęwPlik = new System.Windows.Forms.ToolStripMenuItem();
            this.obOdczytajTablicęZpliku = new System.Windows.Forms.ToolStripMenuItem();
            this.obWyjście = new System.Windows.Forms.ToolStripMenuItem();
            this.obKolory = new System.Windows.Forms.ToolStripMenuItem();
            this.obKolortła = new System.Windows.Forms.ToolStripMenuItem();
            this.obKolorLinii = new System.Windows.Forms.ToolStripMenuItem();
            this.obKolorCzcionki = new System.Windows.Forms.ToolStripMenuItem();
            this.obStylLinii = new System.Windows.Forms.ToolStripMenuItem();
            this.obKropkowa = new System.Windows.Forms.ToolStripMenuItem();
            this.obKreskowa = new System.Windows.Forms.ToolStripMenuItem();
            this.obKreskowoKropkowa = new System.Windows.Forms.ToolStripMenuItem();
            this.obCiągła = new System.Windows.Forms.ToolStripMenuItem();
            this.obGrubośćlinii = new System.Windows.Forms.ToolStripMenuItem();
            this.ob1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob5 = new System.Windows.Forms.ToolStripMenuItem();
            this.obStylCzcionki = new System.Windows.Forms.ToolStripMenuItem();
            this.obKrójPisma = new System.Windows.Forms.ToolStripMenuItem();
            this.obRozmiarCzcionki = new System.Windows.Forms.ToolStripMenuItem();
            this.obPogrubiona = new System.Windows.Forms.ToolStripMenuItem();
            this.obKursywa = new System.Windows.Forms.ToolStripMenuItem();
            this.obAtrybutyObiektuAnimacji = new System.Windows.Forms.ToolStripMenuItem();
            this.obKolor = new System.Windows.Forms.ToolStripMenuItem();
            this.obRozmiar = new System.Windows.Forms.ToolStripMenuItem();
            this.ob025 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob05 = new System.Windows.Forms.ToolStripMenuItem();
            this.ob075 = new System.Windows.Forms.ToolStripMenuItem();
            this.obRozmiar1 = new System.Windows.Forms.ToolStripMenuItem();
            this.obKierunekAnimacji = new System.Windows.Forms.ToolStripMenuItem();
            this.obKierunekAnimacjiwprawo = new System.Windows.Forms.ToolStripMenuItem();
            this.obKierunekAnimacjiLeft = new System.Windows.Forms.ToolStripMenuItem();
            this.obWybórObiektuAnimacji = new System.Windows.Forms.ToolStripMenuItem();
            this.obKuŁKA = new System.Windows.Forms.ToolStripMenuItem();
            this.obProstokąt = new System.Windows.Forms.ToolStripMenuItem();
            this.obprędkośćRuchu = new System.Windows.Forms.ToolStripMenuItem();
            this.ob100procent = new System.Windows.Forms.ToolStripMenuItem();
            this.ob75procent = new System.Windows.Forms.ToolStripMenuItem();
            this.ob50procent = new System.Windows.Forms.ToolStripMenuItem();
            this.ob25procent = new System.Windows.Forms.ToolStripMenuItem();
            this.obpbFormulaSzeregu = new System.Windows.Forms.PictureBox();
            this.obbtnResetuj = new System.Windows.Forms.Button();
            this.obbtnWznowienieAnimacji = new System.Windows.Forms.Button();
            this.obbtnZatrzymanieAnimacji = new System.Windows.Forms.Button();
            this.obbtnStartAnimacji = new System.Windows.Forms.Button();
            this.obbtnGrafik = new System.Windows.Forms.Button();
            this.obbtnTablica = new System.Windows.Forms.Button();
            this.obdgvTablicaSzeregu = new System.Windows.Forms.DataGridView();
            this.ysXColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ysCalculatedColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbRysownica = new System.Windows.Forms.PictureBox();
            this.obtimer = new System.Windows.Forms.Timer(this.components);
            this.obsaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.obLiniowycolorDialog = new System.Windows.Forms.ColorDialog();
            this.obcolorDialogTła = new System.Windows.Forms.ColorDialog();
            this.obFontcolorDialog = new System.Windows.Forms.ColorDialog();
            this.obfontDialog = new System.Windows.Forms.FontDialog();
            this.obKułkacolorDialog = new System.Windows.Forms.ColorDialog();
            this.obMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obpbFormulaSzeregu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvTablicaSzeregu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRysownica)).BeginInit();
            this.SuspendLayout();
            // 
            // obtxth
            // 
            this.obtxth.Location = new System.Drawing.Point(948, 638);
            this.obtxth.Name = "obtxth";
            this.obtxth.Size = new System.Drawing.Size(41, 22);
            this.obtxth.TabIndex = 74;
            this.obtxth.Text = "0,5";
            // 
            // obtxtXg
            // 
            this.obtxtXg.Location = new System.Drawing.Point(585, 633);
            this.obtxtXg.Name = "obtxtXg";
            this.obtxtXg.Size = new System.Drawing.Size(58, 22);
            this.obtxtXg.TabIndex = 73;
            this.obtxtXg.Text = "1";
            // 
            // obtxtXd
            // 
            this.obtxtXd.Location = new System.Drawing.Point(453, 633);
            this.obtxtXd.Name = "obtxtXd";
            this.obtxtXd.Size = new System.Drawing.Size(44, 22);
            this.obtxtXd.TabIndex = 72;
            this.obtxtXd.Text = "-5";
            // 
            // obtxtEps
            // 
            this.obtxtEps.Location = new System.Drawing.Point(337, 632);
            this.obtxtEps.Name = "obtxtEps";
            this.obtxtEps.Size = new System.Drawing.Size(48, 22);
            this.obtxtEps.TabIndex = 71;
            this.obtxtEps.Text = "0,4";
            // 
            // oblbh
            // 
            this.oblbh.AutoSize = true;
            this.oblbh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblbh.Location = new System.Drawing.Point(662, 638);
            this.oblbh.Name = "oblbh";
            this.oblbh.Size = new System.Drawing.Size(252, 19);
            this.oblbh.TabIndex = 70;
            this.oblbh.Text = "Krok (przyrost) h (0.0 < h <1.0) =\r\n";
            // 
            // oblbXg
            // 
            this.oblbXg.AutoSize = true;
            this.oblbXg.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblbXg.Location = new System.Drawing.Point(525, 633);
            this.oblbXg.Name = "oblbXg";
            this.oblbXg.Size = new System.Drawing.Size(44, 19);
            this.oblbXg.TabIndex = 69;
            this.oblbXg.Text = "Xg =";
            // 
            // oblbXd
            // 
            this.oblbXd.AutoSize = true;
            this.oblbXd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblbXd.Location = new System.Drawing.Point(391, 634);
            this.oblbXd.Name = "oblbXd";
            this.oblbXd.Size = new System.Drawing.Size(44, 19);
            this.oblbXd.TabIndex = 68;
            this.oblbXd.Text = "Xd =";
            // 
            // oblbEps
            // 
            this.oblbEps.AutoSize = true;
            this.oblbEps.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oblbEps.Location = new System.Drawing.Point(12, 632);
            this.oblbEps.Name = "oblbEps";
            this.oblbEps.Size = new System.Drawing.Size(299, 19);
            this.oblbEps.TabIndex = 67;
            this.oblbEps.Text = "Dokładność obliczeń Eps (0<Eps<1.0) =";
            // 
            // obMenu
            // 
            this.obMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.obMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menustrip,
            this.obKolory,
            this.obStylLinii,
            this.obGrubośćlinii,
            this.obStylCzcionki,
            this.obAtrybutyObiektuAnimacji,
            this.obKierunekAnimacji,
            this.obWybórObiektuAnimacji,
            this.obprędkośćRuchu});
            this.obMenu.Location = new System.Drawing.Point(0, 0);
            this.obMenu.Name = "obMenu";
            this.obMenu.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.obMenu.Size = new System.Drawing.Size(1705, 28);
            this.obMenu.TabIndex = 66;
            this.obMenu.Text = "menuStrip1";
            // 
            // Menustrip
            // 
            this.Menustrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obZapiszTablicęwPlik,
            this.obOdczytajTablicęZpliku,
            this.obWyjście});
            this.Menustrip.Name = "Menustrip";
            this.Menustrip.Size = new System.Drawing.Size(46, 24);
            this.Menustrip.Text = "Plik";
            // 
            // obZapiszTablicęwPlik
            // 
            this.obZapiszTablicęwPlik.Name = "obZapiszTablicęwPlik";
            this.obZapiszTablicęwPlik.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.obZapiszTablicęwPlik.Size = new System.Drawing.Size(299, 26);
            this.obZapiszTablicęwPlik.Text = "Zapisz tablicę w plik";
            this.obZapiszTablicęwPlik.Click += new System.EventHandler(this.obZapiszTablicęwPlik_Click);
            // 
            // obOdczytajTablicęZpliku
            // 
            this.obOdczytajTablicęZpliku.Name = "obOdczytajTablicęZpliku";
            this.obOdczytajTablicęZpliku.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.obOdczytajTablicęZpliku.Size = new System.Drawing.Size(299, 26);
            this.obOdczytajTablicęZpliku.Text = "Odczytaj tablicę z pliku";
            this.obOdczytajTablicęZpliku.Click += new System.EventHandler(this.obOdczytajTablicęZpliku_Click);
            // 
            // obWyjście
            // 
            this.obWyjście.Name = "obWyjście";
            this.obWyjście.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.obWyjście.Size = new System.Drawing.Size(299, 26);
            this.obWyjście.Text = "Exit";
            this.obWyjście.Click += new System.EventHandler(this.obWyjście_Click);
            // 
            // obKolory
            // 
            this.obKolory.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKolortła,
            this.obKolorLinii,
            this.obKolorCzcionki});
            this.obKolory.Name = "obKolory";
            this.obKolory.Size = new System.Drawing.Size(66, 24);
            this.obKolory.Text = "Kolory";
            // 
            // obKolortła
            // 
            this.obKolortła.Name = "obKolortła";
            this.obKolortła.Size = new System.Drawing.Size(212, 26);
            this.obKolortła.Text = "Kolor tła wykresu";
            this.obKolortła.Click += new System.EventHandler(this.obKolortła_Click);
            // 
            // obKolorLinii
            // 
            this.obKolorLinii.Name = "obKolorLinii";
            this.obKolorLinii.Size = new System.Drawing.Size(212, 26);
            this.obKolorLinii.Text = "Kolor linii wykresu";
            this.obKolorLinii.Click += new System.EventHandler(this.obKolorLinii_Click);
            // 
            // obKolorCzcionki
            // 
            this.obKolorCzcionki.Name = "obKolorCzcionki";
            this.obKolorCzcionki.Size = new System.Drawing.Size(212, 26);
            this.obKolorCzcionki.Text = "Kolor czcionki";
            this.obKolorCzcionki.Click += new System.EventHandler(this.obKolorCzcionki_Click);
            // 
            // obStylLinii
            // 
            this.obStylLinii.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKropkowa,
            this.obKreskowa,
            this.obKreskowoKropkowa,
            this.obCiągła});
            this.obStylLinii.Name = "obStylLinii";
            this.obStylLinii.Size = new System.Drawing.Size(75, 24);
            this.obStylLinii.Text = "Styl linii";
            // 
            // obKropkowa
            // 
            this.obKropkowa.Name = "obKropkowa";
            this.obKropkowa.Size = new System.Drawing.Size(227, 26);
            this.obKropkowa.Text = "Kropkowa";
            this.obKropkowa.Click += new System.EventHandler(this.obKropkowa_Click);
            // 
            // obKreskowa
            // 
            this.obKreskowa.Name = "obKreskowa";
            this.obKreskowa.Size = new System.Drawing.Size(227, 26);
            this.obKreskowa.Text = "Kreskowa";
            this.obKreskowa.Click += new System.EventHandler(this.obKreskowa_Click);
            // 
            // obKreskowoKropkowa
            // 
            this.obKreskowoKropkowa.Name = "obKreskowoKropkowa";
            this.obKreskowoKropkowa.Size = new System.Drawing.Size(227, 26);
            this.obKreskowoKropkowa.Text = "Kreskowo-kropkowa";
            this.obKreskowoKropkowa.Click += new System.EventHandler(this.obKreskowoKropkowa_Click);
            // 
            // obCiągła
            // 
            this.obCiągła.Name = "obCiągła";
            this.obCiągła.Size = new System.Drawing.Size(227, 26);
            this.obCiągła.Text = "Ciągła";
            this.obCiągła.Click += new System.EventHandler(this.obCiągła_Click);
            // 
            // obGrubośćlinii
            // 
            this.obGrubośćlinii.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ob1,
            this.ob2,
            this.ob3,
            this.ob4,
            this.ob5});
            this.obGrubośćlinii.Name = "obGrubośćlinii";
            this.obGrubośćlinii.Size = new System.Drawing.Size(105, 24);
            this.obGrubośćlinii.Text = "Grubość linii";
            // 
            // ob1
            // 
            this.ob1.Name = "ob1";
            this.ob1.Size = new System.Drawing.Size(100, 26);
            this.ob1.Text = "1";
            this.ob1.Click += new System.EventHandler(this.ob1_Click);
            // 
            // ob2
            // 
            this.ob2.Name = "ob2";
            this.ob2.Size = new System.Drawing.Size(100, 26);
            this.ob2.Text = "2";
            this.ob2.Click += new System.EventHandler(this.ob2_Click);
            // 
            // ob3
            // 
            this.ob3.Name = "ob3";
            this.ob3.Size = new System.Drawing.Size(100, 26);
            this.ob3.Text = "3";
            this.ob3.Click += new System.EventHandler(this.ob3_Click);
            // 
            // ob4
            // 
            this.ob4.Name = "ob4";
            this.ob4.Size = new System.Drawing.Size(100, 26);
            this.ob4.Text = "4";
            this.ob4.Click += new System.EventHandler(this.ob4_Click);
            // 
            // ob5
            // 
            this.ob5.Name = "ob5";
            this.ob5.Size = new System.Drawing.Size(100, 26);
            this.ob5.Text = "5";
            this.ob5.Click += new System.EventHandler(this.ob5_Click);
            // 
            // obStylCzcionki
            // 
            this.obStylCzcionki.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKrójPisma,
            this.obRozmiarCzcionki,
            this.obPogrubiona,
            this.obKursywa});
            this.obStylCzcionki.Name = "obStylCzcionki";
            this.obStylCzcionki.Size = new System.Drawing.Size(104, 24);
            this.obStylCzcionki.Text = "Styl czcionki";
            // 
            // obKrójPisma
            // 
            this.obKrójPisma.Name = "obKrójPisma";
            this.obKrójPisma.Size = new System.Drawing.Size(204, 26);
            this.obKrójPisma.Text = "Krój pisma";
            this.obKrójPisma.Click += new System.EventHandler(this.obKrójPisma_Click);
            // 
            // obRozmiarCzcionki
            // 
            this.obRozmiarCzcionki.Name = "obRozmiarCzcionki";
            this.obRozmiarCzcionki.Size = new System.Drawing.Size(204, 26);
            this.obRozmiarCzcionki.Text = "Rozmiar czcionki";
            this.obRozmiarCzcionki.Click += new System.EventHandler(this.obRozmiarCzcionki_Click);
            // 
            // obPogrubiona
            // 
            this.obPogrubiona.Name = "obPogrubiona";
            this.obPogrubiona.Size = new System.Drawing.Size(204, 26);
            this.obPogrubiona.Text = "Pogrubiona";
            this.obPogrubiona.Click += new System.EventHandler(this.obPogrubiona_Click);
            // 
            // obKursywa
            // 
            this.obKursywa.Name = "obKursywa";
            this.obKursywa.Size = new System.Drawing.Size(204, 26);
            this.obKursywa.Text = "Kursywa";
            this.obKursywa.Click += new System.EventHandler(this.obKursywa_Click);
            // 
            // obAtrybutyObiektuAnimacji
            // 
            this.obAtrybutyObiektuAnimacji.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKolor,
            this.obRozmiar});
            this.obAtrybutyObiektuAnimacji.Name = "obAtrybutyObiektuAnimacji";
            this.obAtrybutyObiektuAnimacji.Size = new System.Drawing.Size(193, 24);
            this.obAtrybutyObiektuAnimacji.Text = "Atrybuty obiektu animacji";
            // 
            // obKolor
            // 
            this.obKolor.Name = "obKolor";
            this.obKolor.Size = new System.Drawing.Size(147, 26);
            this.obKolor.Text = "Kolor";
            this.obKolor.Click += new System.EventHandler(this.obKolor_Click);
            // 
            // obRozmiar
            // 
            this.obRozmiar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ob025,
            this.ob05,
            this.ob075,
            this.obRozmiar1});
            this.obRozmiar.Name = "obRozmiar";
            this.obRozmiar.Size = new System.Drawing.Size(147, 26);
            this.obRozmiar.Text = "Rozmiar";
            // 
            // ob025
            // 
            this.ob025.Name = "ob025";
            this.ob025.Size = new System.Drawing.Size(119, 26);
            this.ob025.Text = "0.25";
            this.ob025.Click += new System.EventHandler(this.ob025_Click);
            // 
            // ob05
            // 
            this.ob05.Name = "ob05";
            this.ob05.Size = new System.Drawing.Size(119, 26);
            this.ob05.Text = "0.5";
            this.ob05.Click += new System.EventHandler(this.ob05_Click);
            // 
            // ob075
            // 
            this.ob075.Name = "ob075";
            this.ob075.Size = new System.Drawing.Size(119, 26);
            this.ob075.Text = "0.75";
            this.ob075.Click += new System.EventHandler(this.ob075_Click);
            // 
            // obRozmiar1
            // 
            this.obRozmiar1.Name = "obRozmiar1";
            this.obRozmiar1.Size = new System.Drawing.Size(119, 26);
            this.obRozmiar1.Text = "1";
            this.obRozmiar1.Click += new System.EventHandler(this.obRozmiar1_Click);
            // 
            // obKierunekAnimacji
            // 
            this.obKierunekAnimacji.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKierunekAnimacjiwprawo,
            this.obKierunekAnimacjiLeft});
            this.obKierunekAnimacji.Name = "obKierunekAnimacji";
            this.obKierunekAnimacji.Size = new System.Drawing.Size(140, 24);
            this.obKierunekAnimacji.Text = "Kierunek animacji";
            // 
            // obKierunekAnimacjiwprawo
            // 
            this.obKierunekAnimacjiwprawo.Name = "obKierunekAnimacjiwprawo";
            this.obKierunekAnimacjiwprawo.Size = new System.Drawing.Size(148, 26);
            this.obKierunekAnimacjiwprawo.Text = "Wprawo";
            this.obKierunekAnimacjiwprawo.Click += new System.EventHandler(this.obKierunekAnimacjiwprawo_Click);
            // 
            // obKierunekAnimacjiLeft
            // 
            this.obKierunekAnimacjiLeft.Name = "obKierunekAnimacjiLeft";
            this.obKierunekAnimacjiLeft.Size = new System.Drawing.Size(148, 26);
            this.obKierunekAnimacjiLeft.Text = "Wlewo";
            this.obKierunekAnimacjiLeft.Click += new System.EventHandler(this.obKierunekAnimacjiLeft_Click);
            // 
            // obWybórObiektuAnimacji
            // 
            this.obWybórObiektuAnimacji.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obKuŁKA,
            this.obProstokąt});
            this.obWybórObiektuAnimacji.Name = "obWybórObiektuAnimacji";
            this.obWybórObiektuAnimacji.Size = new System.Drawing.Size(181, 24);
            this.obWybórObiektuAnimacji.Text = "Wybór obiektu animacji";
            // 
            // obKuŁKA
            // 
            this.obKuŁKA.Name = "obKuŁKA";
            this.obKuŁKA.Size = new System.Drawing.Size(154, 26);
            this.obKuŁKA.Text = "Kułka";
            this.obKuŁKA.Click += new System.EventHandler(this.obKuŁKA_Click);
            // 
            // obProstokąt
            // 
            this.obProstokąt.Name = "obProstokąt";
            this.obProstokąt.Size = new System.Drawing.Size(154, 26);
            this.obProstokąt.Text = "Prostokąt";
            this.obProstokąt.Click += new System.EventHandler(this.obProstokąt_Click);
            // 
            // obprędkośćRuchu
            // 
            this.obprędkośćRuchu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ob100procent,
            this.ob75procent,
            this.ob50procent,
            this.ob25procent});
            this.obprędkośćRuchu.Name = "obprędkośćRuchu";
            this.obprędkośćRuchu.Size = new System.Drawing.Size(122, 24);
            this.obprędkośćRuchu.Text = "Prędkość ruchu";
            // 
            // ob100procent
            // 
            this.ob100procent.Name = "ob100procent";
            this.ob100procent.Size = new System.Drawing.Size(128, 26);
            this.ob100procent.Text = "100%";
            this.ob100procent.Click += new System.EventHandler(this.ob100procent_Click);
            // 
            // ob75procent
            // 
            this.ob75procent.Name = "ob75procent";
            this.ob75procent.Size = new System.Drawing.Size(128, 26);
            this.ob75procent.Text = "75%";
            this.ob75procent.Click += new System.EventHandler(this.ob75procent_Click);
            // 
            // ob50procent
            // 
            this.ob50procent.Name = "ob50procent";
            this.ob50procent.Size = new System.Drawing.Size(128, 26);
            this.ob50procent.Text = "50%";
            this.ob50procent.Click += new System.EventHandler(this.ob50procent_Click);
            // 
            // ob25procent
            // 
            this.ob25procent.Name = "ob25procent";
            this.ob25procent.Size = new System.Drawing.Size(128, 26);
            this.ob25procent.Text = "25%";
            this.ob25procent.Click += new System.EventHandler(this.ob25procent_Click);
            // 
            // obpbFormulaSzeregu
            // 
            this.obpbFormulaSzeregu.Image = ((System.Drawing.Image)(resources.GetObject("obpbFormulaSzeregu.Image")));
            this.obpbFormulaSzeregu.Location = new System.Drawing.Point(12, 31);
            this.obpbFormulaSzeregu.Name = "obpbFormulaSzeregu";
            this.obpbFormulaSzeregu.Size = new System.Drawing.Size(1458, 559);
            this.obpbFormulaSzeregu.TabIndex = 75;
            this.obpbFormulaSzeregu.TabStop = false;
            // 
            // obbtnResetuj
            // 
            this.obbtnResetuj.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.obbtnResetuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.obbtnResetuj.Location = new System.Drawing.Point(1501, 540);
            this.obbtnResetuj.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.obbtnResetuj.Name = "obbtnResetuj";
            this.obbtnResetuj.Size = new System.Drawing.Size(185, 34);
            this.obbtnResetuj.TabIndex = 81;
            this.obbtnResetuj.Text = "Resetuj";
            this.obbtnResetuj.UseVisualStyleBackColor = true;
            this.obbtnResetuj.Click += new System.EventHandler(this.obbtnResetuj_Click);
            // 
            // obbtnWznowienieAnimacji
            // 
            this.obbtnWznowienieAnimacji.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnWznowienieAnimacji.Location = new System.Drawing.Point(1501, 466);
            this.obbtnWznowienieAnimacji.Name = "obbtnWznowienieAnimacji";
            this.obbtnWznowienieAnimacji.Size = new System.Drawing.Size(185, 42);
            this.obbtnWznowienieAnimacji.TabIndex = 82;
            this.obbtnWznowienieAnimacji.Text = "Wznowienie animacji";
            this.obbtnWznowienieAnimacji.UseVisualStyleBackColor = true;
            this.obbtnWznowienieAnimacji.Click += new System.EventHandler(this.btnWznowienieAnimacji_Click);
            // 
            // obbtnZatrzymanieAnimacji
            // 
            this.obbtnZatrzymanieAnimacji.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnZatrzymanieAnimacji.Location = new System.Drawing.Point(1501, 392);
            this.obbtnZatrzymanieAnimacji.Name = "obbtnZatrzymanieAnimacji";
            this.obbtnZatrzymanieAnimacji.Size = new System.Drawing.Size(185, 46);
            this.obbtnZatrzymanieAnimacji.TabIndex = 83;
            this.obbtnZatrzymanieAnimacji.Text = "Zatrzymanie animacji";
            this.obbtnZatrzymanieAnimacji.UseVisualStyleBackColor = true;
            this.obbtnZatrzymanieAnimacji.Click += new System.EventHandler(this.btnZatrzymanieAnimacji_Click);
            // 
            // obbtnStartAnimacji
            // 
            this.obbtnStartAnimacji.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnStartAnimacji.Location = new System.Drawing.Point(1501, 294);
            this.obbtnStartAnimacji.Name = "obbtnStartAnimacji";
            this.obbtnStartAnimacji.Size = new System.Drawing.Size(185, 76);
            this.obbtnStartAnimacji.TabIndex = 84;
            this.obbtnStartAnimacji.Text = "START \r\n(rozpoczęcie animacji)";
            this.obbtnStartAnimacji.UseVisualStyleBackColor = true;
            this.obbtnStartAnimacji.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // obbtnGrafik
            // 
            this.obbtnGrafik.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnGrafik.Location = new System.Drawing.Point(1501, 195);
            this.obbtnGrafik.Name = "obbtnGrafik";
            this.obbtnGrafik.Size = new System.Drawing.Size(185, 81);
            this.obbtnGrafik.TabIndex = 85;
            this.obbtnGrafik.Text = "Graficzna wizualizacja wartości funkcji F(X)";
            this.obbtnGrafik.UseVisualStyleBackColor = true;
            this.obbtnGrafik.Click += new System.EventHandler(this.btnGrafik_Click);
            // 
            // obbtnTablica
            // 
            this.obbtnTablica.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.obbtnTablica.Location = new System.Drawing.Point(1501, 75);
            this.obbtnTablica.Name = "obbtnTablica";
            this.obbtnTablica.Size = new System.Drawing.Size(185, 96);
            this.obbtnTablica.TabIndex = 86;
            this.obbtnTablica.Text = "Tabelaryczna wizualizacja wartości funkcji F(X)";
            this.obbtnTablica.UseVisualStyleBackColor = true;
            this.obbtnTablica.Click += new System.EventHandler(this.btnTablica_Click);
            // 
            // obdgvTablicaSzeregu
            // 
            this.obdgvTablicaSzeregu.AllowUserToAddRows = false;
            this.obdgvTablicaSzeregu.AllowUserToDeleteRows = false;
            this.obdgvTablicaSzeregu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.obdgvTablicaSzeregu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.obdgvTablicaSzeregu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ysXColumn,
            this.ysCalculatedColumn});
            this.obdgvTablicaSzeregu.Location = new System.Drawing.Point(80, 30);
            this.obdgvTablicaSzeregu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.obdgvTablicaSzeregu.Name = "obdgvTablicaSzeregu";
            this.obdgvTablicaSzeregu.ReadOnly = true;
            this.obdgvTablicaSzeregu.RowHeadersWidth = 51;
            this.obdgvTablicaSzeregu.RowTemplate.Height = 28;
            this.obdgvTablicaSzeregu.Size = new System.Drawing.Size(759, 486);
            this.obdgvTablicaSzeregu.TabIndex = 87;
            this.obdgvTablicaSzeregu.Visible = false;
            // 
            // ysXColumn
            // 
            this.ysXColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ysXColumn.HeaderText = "Wartość zmiennej niezależnej X";
            this.ysXColumn.MinimumWidth = 6;
            this.ysXColumn.Name = "ysXColumn";
            this.ysXColumn.ReadOnly = true;
            // 
            // ysCalculatedColumn
            // 
            this.ysCalculatedColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ysCalculatedColumn.HeaderText = "Wartość funkcji F(X)";
            this.ysCalculatedColumn.MinimumWidth = 6;
            this.ysCalculatedColumn.Name = "ysCalculatedColumn";
            this.ysCalculatedColumn.ReadOnly = true;
            // 
            // pbRysownica
            // 
            this.pbRysownica.Location = new System.Drawing.Point(0, 54);
            this.pbRysownica.Name = "pbRysownica";
            this.pbRysownica.Size = new System.Drawing.Size(1458, 500);
            this.pbRysownica.TabIndex = 88;
            this.pbRysownica.TabStop = false;
            this.pbRysownica.Visible = false;
            this.pbRysownica.Paint += new System.Windows.Forms.PaintEventHandler(this.pbRysownica_Paint);
            // 
            // obtimer
            // 
            this.obtimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // WykresZmianWartościSzeregupotęgowego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1705, 726);
            this.Controls.Add(this.obbtnTablica);
            this.Controls.Add(this.obbtnGrafik);
            this.Controls.Add(this.obbtnStartAnimacji);
            this.Controls.Add(this.obbtnZatrzymanieAnimacji);
            this.Controls.Add(this.obbtnWznowienieAnimacji);
            this.Controls.Add(this.obbtnResetuj);
            this.Controls.Add(this.obpbFormulaSzeregu);
            this.Controls.Add(this.obtxth);
            this.Controls.Add(this.obtxtXg);
            this.Controls.Add(this.obtxtXd);
            this.Controls.Add(this.obtxtEps);
            this.Controls.Add(this.oblbh);
            this.Controls.Add(this.oblbXg);
            this.Controls.Add(this.oblbXd);
            this.Controls.Add(this.oblbEps);
            this.Controls.Add(this.obMenu);
            this.Controls.Add(this.obdgvTablicaSzeregu);
            this.Controls.Add(this.pbRysownica);
            this.Name = "WykresZmianWartościSzeregupotęgowego";
            this.Text = "Wykres Zmian Wartości Szeregu potęgowego";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WykresZmianWartościSzeregupotęgowego_FormClosing);
            this.obMenu.ResumeLayout(false);
            this.obMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.obpbFormulaSzeregu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obdgvTablicaSzeregu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRysownica)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox obtxth;
        private System.Windows.Forms.TextBox obtxtXg;
        private System.Windows.Forms.TextBox obtxtXd;
        private System.Windows.Forms.TextBox obtxtEps;
        private System.Windows.Forms.Label oblbh;
        private System.Windows.Forms.Label oblbXg;
        private System.Windows.Forms.Label oblbXd;
        private System.Windows.Forms.Label oblbEps;
        private System.Windows.Forms.MenuStrip obMenu;
        private System.Windows.Forms.ToolStripMenuItem Menustrip;
        private System.Windows.Forms.ToolStripMenuItem obZapiszTablicęwPlik;
        private System.Windows.Forms.ToolStripMenuItem obOdczytajTablicęZpliku;
        private System.Windows.Forms.ToolStripMenuItem obWyjście;
        private System.Windows.Forms.ToolStripMenuItem obKolory;
        private System.Windows.Forms.ToolStripMenuItem obKolortła;
        private System.Windows.Forms.ToolStripMenuItem obKolorLinii;
        private System.Windows.Forms.ToolStripMenuItem obKolorCzcionki;
        private System.Windows.Forms.ToolStripMenuItem obStylLinii;
        private System.Windows.Forms.ToolStripMenuItem obKropkowa;
        private System.Windows.Forms.ToolStripMenuItem obKreskowa;
        private System.Windows.Forms.ToolStripMenuItem obKreskowoKropkowa;
        private System.Windows.Forms.ToolStripMenuItem obCiągła;
        private System.Windows.Forms.ToolStripMenuItem obGrubośćlinii;
        private System.Windows.Forms.ToolStripMenuItem ob1;
        private System.Windows.Forms.ToolStripMenuItem ob2;
        private System.Windows.Forms.ToolStripMenuItem ob3;
        private System.Windows.Forms.ToolStripMenuItem ob4;
        private System.Windows.Forms.ToolStripMenuItem ob5;
        private System.Windows.Forms.ToolStripMenuItem obStylCzcionki;
        private System.Windows.Forms.ToolStripMenuItem obKrójPisma;
        private System.Windows.Forms.ToolStripMenuItem obRozmiarCzcionki;
        private System.Windows.Forms.ToolStripMenuItem obPogrubiona;
        private System.Windows.Forms.ToolStripMenuItem obKursywa;
        private System.Windows.Forms.ToolStripMenuItem obAtrybutyObiektuAnimacji;
        private System.Windows.Forms.ToolStripMenuItem obKolor;
        private System.Windows.Forms.ToolStripMenuItem obRozmiar;
        private System.Windows.Forms.ToolStripMenuItem ob025;
        private System.Windows.Forms.ToolStripMenuItem ob05;
        private System.Windows.Forms.ToolStripMenuItem ob075;
        private System.Windows.Forms.ToolStripMenuItem obRozmiar1;
        private System.Windows.Forms.ToolStripMenuItem obKierunekAnimacji;
        private System.Windows.Forms.ToolStripMenuItem obKierunekAnimacjiwprawo;
        private System.Windows.Forms.ToolStripMenuItem obKierunekAnimacjiLeft;
        private System.Windows.Forms.ToolStripMenuItem obWybórObiektuAnimacji;
        private System.Windows.Forms.ToolStripMenuItem obKuŁKA;
        private System.Windows.Forms.ToolStripMenuItem obProstokąt;
        private System.Windows.Forms.ToolStripMenuItem obprędkośćRuchu;
        private System.Windows.Forms.ToolStripMenuItem ob100procent;
        private System.Windows.Forms.ToolStripMenuItem ob75procent;
        private System.Windows.Forms.ToolStripMenuItem ob50procent;
        private System.Windows.Forms.ToolStripMenuItem ob25procent;
        private System.Windows.Forms.PictureBox obpbFormulaSzeregu;
        private System.Windows.Forms.Button obbtnResetuj;
        private System.Windows.Forms.Button obbtnWznowienieAnimacji;
        private System.Windows.Forms.Button obbtnZatrzymanieAnimacji;
        private System.Windows.Forms.Button obbtnStartAnimacji;
        private System.Windows.Forms.Button obbtnGrafik;
        private System.Windows.Forms.Button obbtnTablica;
        private System.Windows.Forms.DataGridView obdgvTablicaSzeregu;
        private System.Windows.Forms.DataGridViewTextBoxColumn ysXColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ysCalculatedColumn;
        private System.Windows.Forms.PictureBox pbRysownica;
        private System.Windows.Forms.Timer obtimer;
        private System.Windows.Forms.SaveFileDialog obsaveFileDialog;
        private System.Windows.Forms.ColorDialog obLiniowycolorDialog;
        private System.Windows.Forms.ColorDialog obcolorDialogTła;
        private System.Windows.Forms.ColorDialog obFontcolorDialog;
        private System.Windows.Forms.FontDialog obfontDialog;
        private System.Windows.Forms.ColorDialog obKułkacolorDialog;
    }
}

