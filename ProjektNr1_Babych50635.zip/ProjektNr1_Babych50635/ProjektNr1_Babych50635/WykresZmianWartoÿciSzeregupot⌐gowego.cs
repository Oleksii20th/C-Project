﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace ProjektNr1_Babych50635
{
    public partial class WykresZmianWartościSzeregupotęgowego : Form
    {
        //Deklaracja zmiennych: pióra, pędzle, linii toru
        Pen obPióroXY;
        Pen obPióro;


        SolidBrush obPędzel;
        SolidBrush obPędzelC;
        //deklaracja stałych
        const int obMargines = 50;
        int obPromień = 10;
        //deklaracja zmiennych pomocniczych
        int obXCent, obYCent;
        int obXMax, obYMax;
        int obPunktyWjednostkachMiaryOsiX;
        int obPunktyWjednostkachMiaryOsiY;
        int obIndeksKulki;

        //tablicy dla przechowywania punktów
        Point[] obPunkt;


        bool obDod = true;
        //współczynnik skali
        float obSkal;
        Font obCzcionkaInf;
        bool obkulka = true;
        public WykresZmianWartościSzeregupotęgowego()
        {
            InitializeComponent();
            //lokalizacja i rozmiary okna
            this.Location = new Point(10, 10);
            this.Width = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Width * 0.73F);
            this.Height = Convert.ToInt32(Screen.PrimaryScreen.Bounds.Height * 0.78F);
            //ustalenie lokalizacji i kontrolki Picturebox
            pbRysownica.Location = new Point(this.Left + 40, this.Top + 40);
            pbRysownica.Width = (int)(this.Width * 0.95F);
            pbRysownica.Height = (int)(this.Height * 0.85F);
            pbRysownica.BackColor = Color.LightGreen;
            pbRysownica.BorderStyle = BorderStyle.Fixed3D;
            //ustawienie pędzela
            obPędzel = new SolidBrush(Color.Black);
            //ustawienie zmiennych pomocniczych
            obXMax = this.Size.Width - 2 * obMargines;
            obYMax = this.Size.Height - 2 * obMargines;
            obXCent = obXMax / 2;
            obYCent = obYMax / 2;
            //ustawienie piór dla osi układu współrzędnych, torów
            obPióroXY = new Pen(Color.Black, 2F);
            obPióroXY.DashStyle = DashStyle.Solid;
            obPióro = new Pen(Color.Blue, 2F);
            obPióro.DashStyle = DashStyle.Solid;

            //ysColor.BackColor = Color.Blue;

            //ustawienie współczynnika skali
            obSkal = obYMax / 8;
            obPunktyWjednostkachMiaryOsiY = (int)(obSkal * Math.PI);
            obPunktyWjednostkachMiaryOsiX = 4 * obPunktyWjednostkachMiaryOsiY;
            //ustawienie rozmiarów tablic dla przechowywania punktów
            obPunkt = new Point[obPunktyWjednostkachMiaryOsiX + 1];



            //ustawienie początkowych indeksów pozycji kułek
            obIndeksKulki = 0;
            //deklaracja zmiennych dla rysowania
            int obFi;
            float obFiWradianach;
            int obDx = (obXMax - 2 * obMargines) / obPunktyWjednostkachMiaryOsiX;
            int obIndexPunktówOsiX;
            for (obFi = obXCent - obPunktyWjednostkachMiaryOsiX / 2 + obMargines, obIndexPunktówOsiX = 0;
                obIndexPunktówOsiX <= obPunktyWjednostkachMiaryOsiX; obFi += obDx)
            {
                obFiWradianach = (float)((obFi * Math.PI) / 180);
                obPunkt[obIndexPunktówOsiX] = new Point(obFi, obYCent - (int)(obSkal * Math.Sin(obFiWradianach)));

                obIndexPunktówOsiX++;
            }

            obPędzelC = new SolidBrush(Color.Red);
            //font dla opisu osi
            obCzcionkaInf = new Font("Arial", 12);
            this.DoubleBuffered = true;

            //ustawienie zegarka
            obtimer.Interval = 200;
            obtimer.Enabled = false;

            //ustawienia przycisków
            obbtnWznowienieAnimacji.Enabled = false;
            obbtnZatrzymanieAnimacji.Enabled = false;
            obbtnGrafik.Enabled = false;
            obbtnStartAnimacji.Enabled = false;
        }

        private void btnWznowienieAnimacji_Click(object sender, EventArgs e)
        {
            obtimer.Enabled = true;
            obbtnWznowienieAnimacji.Enabled = false;
            obbtnZatrzymanieAnimacji.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (obDod)
            {

                obIndeksKulki += 2;
            }
            else obIndeksKulki -= 2;

            if (obIndeksKulki >= obPunkt.Length - 2 || obIndeksKulki == 0)
                obDod = !obDod;
            this.Refresh();
        }

        private void pbRysownica_Paint(object sender, PaintEventArgs e)
        {

            //powiększamy strzałki na osi x/y
            AdjustableArrowCap obbigArrow = new AdjustableArrowCap(5, 10);
            obPióroXY.StartCap = LineCap.Square;
            obPióroXY.CustomEndCap = obbigArrow;
            //rysowanie osi układu współrzędnych
            e.Graphics.DrawLine(obPióroXY, obMargines, obYCent, obXMax - obMargines, obYCent);
            e.Graphics.DrawLine(obPióroXY, obXCent, obYMax - 2 * obMargines, obXCent, obMargines);
            PointF obLokalizacjaYinf = new PointF(obXCent, obMargines / 2);
            e.Graphics.DrawString("y", obCzcionkaInf, obPędzel, obLokalizacjaYinf);
            PointF obLokalizacjaX = new PointF(obXMax - obMargines, obYCent);
            e.Graphics.DrawString("x", obCzcionkaInf, obPędzel, obLokalizacjaX);
            //rysowanie linii toru
            e.Graphics.DrawCurve(obPióro, obPunkt);
            //rysowanie kułki na torze ruchu
            if (obkulka)
            {
                e.Graphics.FillEllipse(obPędzelC, obPunkt[obIndeksKulki].X - obPromień,
                    obPunkt[obIndeksKulki].Y - obPromień, obPromień + obPromień, obPromień + obPromień);
            }
            else
            {
                e.Graphics.FillRectangle(obPędzelC, obPunkt[obIndeksKulki].X - obPromień,
                    obPunkt[obIndeksKulki].Y - obPromień, obPromień + obPromień, obPromień + obPromień);
            }
        }
        float obSumaSzeregu(float obX, float obEps, out ushort obLicznikWyrazowSzeregu)
        {//deklaracje uzupełniające
            float obW, obSuma;
            //ustalenie początkowego stanu obliczeń
            obW = 1.0F;
            obLicznikWyrazowSzeregu = 1;
            obSuma = 0.0F;
            //iteracyjne obliczanie sumy szeregu potęgowego
            do
            {
                obSuma = obSuma + obW;
                obLicznikWyrazowSzeregu++;
                obW = obW *( obLicznikWyrazowSzeregu * obX * (1.0F - obX))/((obLicznikWyrazowSzeregu - 1) * obX * (1.0F - obX));
            } while (Math.Abs(obW) > obEps);
            //zwrotne przekazanie wyniku obliczeń
            return obSuma;

        }
        private void obTabelarycznaSuma(float obEps, float obXg, float obXd, float obh)
        {
            int obA = 0;

            ushort obSuma;
            for (float obi = obXd; obi < obXg + obEps; obi += obh)
            {
                obSumaSzeregu(obi, obEps, out obSuma);
                obdgvTablicaSzeregu.Rows.Add();
                obdgvTablicaSzeregu.Rows[obA].Cells[0].Value = obi;
                obdgvTablicaSzeregu.Rows[obA].Cells[1].Value = obSuma;
                obA++;
            }

        }

        private void btnGrafik_Click(object sender, EventArgs e)
        {
            obpbFormulaSzeregu.Visible = false;
            obdgvTablicaSzeregu.Visible = false;
            pbRysownica.Visible = true;
            obbtnStartAnimacji.Enabled = true;
            oblbEps.Visible = false;
            oblbh.Visible = false;
            oblbXd.Visible = false;
            oblbXg.Visible = false;
            obtxtEps.Visible = false;
            obtxth.Visible = false;
            obtxtXd.Visible = false;
            obtxtXg.Visible = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            obtimer.Interval = 200;
            obtimer.Enabled = true;
            obbtnZatrzymanieAnimacji.Enabled = true;
        }

        private void btnZatrzymanieAnimacji_Click(object sender, EventArgs e)
        {
            obtimer.Enabled = false;
            obbtnWznowienieAnimacji.Enabled = true;
            obbtnZatrzymanieAnimacji.Enabled = false;
        }
        private void obResetujTabelaryczne()
        {
              
            obdgvTablicaSzeregu.Visible = false;
            pbRysownica.Visible = false;
            obdgvTablicaSzeregu.Rows.Clear();
            obbtnTablica.Enabled = true;
            obtxtEps.Enabled = true;
            obtxtXd.Enabled = true;
            obtxtXg.Enabled = true;
            obtxth.Enabled = true;
            oblbEps.Visible = true;
            oblbh.Visible = true;
            oblbXd.Visible = true;
            oblbXg.Visible = true;
            obtxtEps.Visible = true;
            obtxth.Visible = true;
            obtxtXd.Visible = true;
            obtxtXg.Visible = true;
            obpbFormulaSzeregu.Visible = true;
            obbtnGrafik.Enabled = false;
            obbtnStartAnimacji.Enabled = false;
            obbtnWznowienieAnimacji.Enabled = false;
            obbtnZatrzymanieAnimacji.Enabled = false;
        }

        private void obZapiszTablicęwPlik_Click(object sender, EventArgs e)
        {
            Stream oby = null;
            if (obsaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if ((oby = obsaveFileDialog.OpenFile()) != null)
                {
                    StreamWriter obNapisz = new StreamWriter(oby);
                    try
                    {
                        for (int obi = 0; obi < obdgvTablicaSzeregu.RowCount; obi++)
                        {
                            for (int oba = 0; oba < obdgvTablicaSzeregu.ColumnCount; oba++)
                            {
                                obNapisz.Write(obdgvTablicaSzeregu.Rows[obi].Cells[oba].Value);
                                obNapisz.Write(" ");
                            }
                            obNapisz.WriteLine();
                        }
                    }
                    catch (Exception obW)
                    {
                        MessageBox.Show(obW.Message);
                    }
                    finally
                    {
                        obNapisz.Close();
                    }
                }
            }
        }

        private void obOdczytajTablicęZpliku_Click(object sender, EventArgs e)
        {
            Stream obn = null;
            obdgvTablicaSzeregu.Rows.Clear();
            //anulowania metody
            if (obsaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if ((obn = obsaveFileDialog.OpenFile()) != null)
                {
                    StreamReader oba = new StreamReader(obn);
                    string[] obc;
                    int obk = 0;
                    try
                    {
                        string[] obu = oba.ReadToEnd().Split('\n');
                        obk = obu.Count();
                        obdgvTablicaSzeregu.RowCount = obk;
                        for (int obq = 0; obq < obk; obq++)
                        {
                            obc = obu[obq].Split(' ');
                            for (int obi = 0; obi < obdgvTablicaSzeregu.ColumnCount; obi++)
                            {
                                try
                                {
                                    obdgvTablicaSzeregu.Rows[obq].Cells[obi].Value = double.Parse(obc[obi]);
                                }
                                catch { }
                            }
                        }
                    }
                    catch (Exception obd)
                    {
                        MessageBox.Show(obd.Message);
                    }
                    finally
                    {
                        oba.Close();
                    }
                }
            }
        }

        private void obWyjście_Click(object sender, EventArgs e)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
             MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
             this.Text,
             MessageBoxButtons.YesNoCancel,
             MessageBoxIcon.Question,
             MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;

            }
        }

        private void obKolortła_Click(object sender, EventArgs e)
        {
            if (obcolorDialogTła.ShowDialog() == DialogResult.OK)
            {
                pbRysownica.BackColor = obcolorDialogTła.Color;
            }
        }

        private void obKolorLinii_Click(object sender, EventArgs e)
        {
            if (obLiniowycolorDialog.ShowDialog() == DialogResult.OK)
            {
                obPióro.Color = obLiniowycolorDialog.Color;
            }
            
        }

        private void obKolorCzcionki_Click(object sender, EventArgs e)
        {
            if (obFontcolorDialog.ShowDialog() == DialogResult.OK)
            {
                this.ForeColor = obFontcolorDialog.Color;
            }
        }

        private void obKropkowa_Click(object sender, EventArgs e)
        {
            obPióro.DashStyle = DashStyle.Dot;
        }

        private void obKreskowa_Click(object sender, EventArgs e)
        {
            obPióro.DashStyle = DashStyle.Dash;
        }

        private void obKreskowoKropkowa_Click(object sender, EventArgs e)
        {
            obPióro.DashStyle = DashStyle.DashDot;
        }

        private void obCiągła_Click(object sender, EventArgs e)
        {
            obPióro.DashStyle = DashStyle.Solid;
        }

        private void ob1_Click(object sender, EventArgs e)
        {
            obPióro.Width = 1;
        }

        private void ob2_Click(object sender, EventArgs e)
        {
            obPióro.Width = 2;
        }

        private void ob3_Click(object sender, EventArgs e)
        {
            obPióro.Width = 3;

        }

        private void ob4_Click(object sender, EventArgs e)
        {
            obPióro.Width = 4;

        }

        private void ob5_Click(object sender, EventArgs e)
        {
            obPióro.Width = 5;

        }

        private void obKrójPisma_Click(object sender, EventArgs e)
        {
            if(obfontDialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = obfontDialog.Font;
            }
        }

        private void obRozmiarCzcionki_Click(object sender, EventArgs e)
        {
            if (obfontDialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = obfontDialog.Font;
            }
        }

        private void obPogrubiona_Click(object sender, EventArgs e)
        {
            if (obfontDialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = new Font(this.Font, FontStyle.Bold);
            }
        }

        private void obKursywa_Click(object sender, EventArgs e)
        {
            if (obfontDialog.ShowDialog() == DialogResult.OK)
            {
                this.Font = new Font(this.Font, FontStyle.Italic);
            }

        }

        private void obKolor_Click(object sender, EventArgs e)
        {
            if(obKułkacolorDialog.ShowDialog() == DialogResult.OK)
            {
                obPędzelC.Color = obKułkacolorDialog.Color;
            }
        }

        private void ob025_Click(object sender, EventArgs e)
        {
            obPromień = 10;
        }

        private void ob05_Click(object sender, EventArgs e)
        {
            obPromień = 20;
        }

        private void ob075_Click(object sender, EventArgs e)
        {
            obPromień = 30;
        }

        private void obRozmiar1_Click(object sender, EventArgs e)
        {
            obPromień = 40;
        }

        private void obKierunekAnimacjiwprawo_Click(object sender, EventArgs e)
        {
            obDod = true;
        }

        private void obKierunekAnimacjiLeft_Click(object sender, EventArgs e)
        {
            obDod = false;
        }

        private void obKuŁKA_Click(object sender, EventArgs e)
        {
            obkulka = true;

        }

        private void obProstokąt_Click(object sender, EventArgs e)
        {
            obkulka = false;
        }

        private void ob100procent_Click(object sender, EventArgs e)
        {
            obtimer.Interval = 5;
        }

        private void ob75procent_Click(object sender, EventArgs e)
        {
            obtimer.Interval = 25;
        }

        private void ob50procent_Click(object sender, EventArgs e)
        {
            obtimer.Interval = 75;
        }

        private void ob25procent_Click(object sender, EventArgs e)
        {
            obtimer.Interval = 100;
        }

        private void WykresZmianWartościSzeregupotęgowego_FormClosing(object sender, FormClosingEventArgs obe)
        {
            DialogResult obPytanieDoUżytkownikaAplikacji =
               MessageBox.Show("Czy rzewiście chcesz zamknąć ten formularz",
               this.Text,
               MessageBoxButtons.YesNoCancel,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button3);
            switch (obPytanieDoUżytkownikaAplikacji)
            {
                case DialogResult.Yes:
                    MessageBox.Show("Teraz nastąpił zamknięcia formularza" + this.Text);
                    Application.ExitThread();

                    break;
                case DialogResult.No:
                    MessageBox.Show("Formularz nie będzie zamknięty (a przyczyną wywołania" +
                        "zdarzenia było:" + obe.CloseReason + ")");
                    obe.Cancel = true;

                    break;
                case DialogResult.Cancel:
                    MessageBox.Show("Anoluwanie zamknięcia formularza (a przyczyną wywołania " + "zdarzenia było:" + this.Text +
                        ")");
                    obe.Cancel = true;
                    break;
            }
        }


        private void obbtnResetuj_Click(object sender, EventArgs e)
        {
            obResetujTabelaryczne();
        }

        private void btnTablica_Click(object sender, EventArgs e)
        {

            float obEps = 0.0F; float obXg = 0.0F;
            float obXd = 0.0F; float obh = 0.0F;

            if (!float.TryParse(obtxtXd.Text, out obXd))
            {
                MessageBox.Show("ERROR: w zapisie wartości dolnej granicy Xd wystąpił niedozwolony znak!");
                obResetujTabelaryczne();
            }

            else if (!float.TryParse(obtxtEps.Text, out obEps))
            {
                MessageBox.Show("ERROR: w zapisie wartości dokładności obliczeń EPS wystąpił niedozwolony znak!");
                obResetujTabelaryczne();
            }
            else if (obEps >= 1 || obEps <= 0)
            {
                MessageBox.Show("ERROR! Eps musi być 0 < Eps < 1");
                obResetujTabelaryczne();
            }
            else if (!float.TryParse(obtxtXg.Text, out obXg))
            {
                MessageBox.Show("ERROR: w zapisie wartości górnej granicy Xg wystąpił niedozwolony znak!");
                obResetujTabelaryczne();
            }

            else if (!float.TryParse(obtxth.Text, out obh))
            {
                MessageBox.Show("ERROR: w zapisie wartości h wystąpił niedozwolony znak!");
                obResetujTabelaryczne();
            }
            else if (obh <= 0 || obh >= 1)
            {
                MessageBox.Show("ERROR: h musi być 0.0 < h < 1.0");
                obResetujTabelaryczne();
            }
            else if (obXg < obXd)
            {
                MessageBox.Show("ERROR: Xg musi być więcej od Xd!");
                obResetujTabelaryczne();
            }
            else
            {
                obTabelarycznaSuma(obEps, obXg, obXd, obh);
                obdgvTablicaSzeregu.Visible = true;
                obdgvTablicaSzeregu.Enabled = false;
            }
            obbtnGrafik.Enabled = true;
            obpbFormulaSzeregu.Visible = false;
            obtxtEps.Enabled = false;
            obtxtXd.Enabled = false;
            obtxtXg.Enabled = false;
            pbRysownica.Visible = false;
            obtxth.Enabled = false;
            obbtnTablica.Enabled = false;
        }
    }
    
}
